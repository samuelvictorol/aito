@echo off
call "%~dp0Iniciar AitoIA.bat" -UpdateOnly
