@echo off
"%~dp0plugin\Configurar AitoCodex Key.exe"
exit /b %errorlevel%
