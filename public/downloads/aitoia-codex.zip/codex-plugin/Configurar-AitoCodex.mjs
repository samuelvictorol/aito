import { spawn } from 'node:child_process';
import { readFile, unlink, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { createInterface } from 'node:readline';
import { pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';

const providerId = 'aitotokens';
const gateway = 'https://api.aitosoftwares.com/aito-tokens/codex/v1';
const settings = {
  model_provider: providerId,
  model: 'gpt-6.1-sol',
  model_reasoning_effort: 'xhigh',
  model_context_window: 160000,
  model_auto_compact_token_limit: 125000,
  web_search: 'disabled',
};

class ConfigurationError extends Error {}

const patch = (keyPath, value) => ({ keyPath, value, mergeStrategy: 'replace' });

function userConfigLayer(read) {
  return read.layers?.find(({ name }) => name.type === 'user' && !name.profile);
}

function providerStatePath(layer) {
  const file = layer?.name.file;
  if (!file) throw new ConfigurationError('O Codex não informou onde fica a configuração do usuário. Atualize o Codex e tente novamente.');
  return join(dirname(file), 'aitoia-provider-state.json');
}

async function saveProviderState(file, config) {
  const previous = Object.fromEntries(Object.keys(settings).map(key => [key, config[key] ?? null]));
  try {
    await writeFile(file, JSON.stringify({ version: 1, previous }), { flag: 'wx', mode: 0o600 });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
  }
}

async function readProviderState(file) {
  try {
    const state = JSON.parse(await readFile(file, 'utf8'));
    const snapshot = state?.previous;
    if (state?.version === 1 && snapshot && Object.keys(settings).every(key => {
      const value = snapshot[key];
      return value === null || typeof value === typeof settings[key];
    }) && snapshot.model_provider !== providerId) return snapshot;
  } catch (error) {
    if (!(error instanceof SyntaxError) && error.code !== 'ENOENT') throw error;
  }
  return null;
}

async function withCodexConfig(command, prefix, callback) {
  const child = spawn(command, [...prefix, 'app-server', '--listen', 'stdio://'], {
    cwd: homedir(),
    stdio: ['pipe', 'pipe', 'ignore'],
    windowsHide: true,
  });
  child.on('error', () => {});
  child.stdin.on('error', () => {});
  const lines = createInterface({ input: child.stdout, crlfDelay: Infinity });
  const response = lines[Symbol.asyncIterator]();
  const timeout = setTimeout(() => {
    child.kill();
    lines.close();
  }, 30_000);
  let serial = 0;

  function send(message) {
    child.stdin.write(JSON.stringify(message) + '\n');
  }

  async function request(method, params) {
    const id = ++serial;
    send({ id, method, params });
    while (true) {
      const line = await response.next();
      if (line.done) {
        throw new ConfigurationError('O Codex não respondeu à configuração. Confira se o app e a CLI estão atualizados.');
      }
      const message = JSON.parse(line.value);
      if (message.id !== id) continue;
      if (message.error) {
        throw new ConfigurationError('O Codex recusou a alteração de configuração. Verifique o config.toml e tente novamente.');
      }
      return message.result;
    }
  }

  try {
    await request('initialize', { clientInfo: { name: 'aitosoftwares-launcher', version: '1.0.0' } });
    send({ method: 'initialized' });
    return await callback(request);
  } finally {
    clearTimeout(timeout);
    lines.close();
    child.stdin.end();
    child.kill();
  }
}

function verifyGateway(provider) {
  if (provider && provider.base_url !== gateway) {
    throw new ConfigurationError('O provedor aitotokens no config.toml usa um endereço diferente da AitoSoftwares. Revise essa configuração antes de continuar.');
  }
}

function verifyEffectiveConfig(config, provider) {
  const activeProvider = config?.model_providers?.[providerId];
  if (config?.model_provider !== providerId ||
      activeProvider?.base_url !== gateway ||
      activeProvider.auth?.command !== provider.auth.command ||
      !isDeepStrictEqual(activeProvider.auth?.args, provider.auth.args) ||
      activeProvider?.env_key || activeProvider?.requires_openai_auth ||
      activeProvider?.experimental_bearer_token || activeProvider?.query_params ||
      activeProvider?.http_headers || activeProvider?.env_http_headers) {
    throw new ConfigurationError('Outra camada de configuração do Codex está substituindo o provedor AitoTokens. Revise a configuração efetiva para evitar consumo pela conta errada.');
  }
}

async function configure({ command, prefix, powerShell, credentialScript, switchProvider, checkOnly }) {
  const provider = {
    name: 'AitoTokens',
    base_url: gateway,
    wire_api: 'responses',
    supports_websockets: false,
    request_max_retries: 0,
    stream_max_retries: 0,
    capabilities: { remote_compaction: 'unsupported' },
    auth: {
      command: powerShell,
      args: ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'RemoteSigned', '-File', credentialScript, '-Mode', 'Read'],
      timeout_ms: 10_000,
    },
  };

  return withCodexConfig(command, prefix, async (request) => {
    const read = await request('config/read', { includeLayers: true });
    const userLayer = userConfigLayer(read);
    const userConfig = userLayer?.config ?? {};
    const savedProvider = userConfig.model_providers?.[providerId];
    verifyGateway(savedProvider);
    verifyGateway(read.config.model_providers?.[providerId]);

    const selectedProvider = read.config.model_provider;
    if (selectedProvider && !['openai', providerId].includes(selectedProvider) && !switchProvider) {
      return 'provider-conflict';
    }

    const edits = [];
    if (!isDeepStrictEqual(savedProvider, provider)) {
      edits.push(patch(`model_providers.${providerId}`, provider));
    }
    const changingProvider = userConfig.model_provider !== providerId;
    for (const [keyPath, value] of Object.entries(settings)) {
      if (userConfig[keyPath] !== value && (changingProvider || userConfig[keyPath] == null)) {
        edits.push(patch(keyPath, value));
      }
    }
    if (checkOnly && edits.length) return 'can-configure';
    if (edits.length) {
      if (changingProvider) await saveProviderState(providerStatePath(userLayer), userConfig);
      await request('config/batchWrite', {
        edits,
        expectedVersion: userLayer?.version ?? null,
        reloadUserConfig: true,
      });
    }
    const configured = edits.length ? await request('config/read', { includeLayers: false }) : read;
    verifyEffectiveConfig(configured.config, provider);
    return edits.length ? 'updated' : 'ready';
  });
}

export function providerRemovalEdits(config, previous) {
  const provider = config.model_providers?.[providerId];
  const edits = [];
  if (provider?.base_url === gateway) edits.push(patch(`model_providers.${providerId}`, null));
  if (config.model_provider !== providerId || (provider && provider.base_url !== gateway)) return edits;

  for (const [key, value] of Object.entries(settings)) {
    if (config[key] !== undefined && (key === 'model_provider' || key === 'model' || config[key] === value)) {
      edits.push(patch(key, previous?.[key] ?? null));
    }
  }
  return edits;
}

async function restore(command, prefix) {
  return withCodexConfig(command, prefix, async request => {
    const read = await request('config/read', { includeLayers: true });
    const layer = userConfigLayer(read);
    const file = providerStatePath(layer);
    const current = layer?.config ?? {};
    const previous = await readProviderState(file);
    const edits = providerRemovalEdits(current, previous);
    if (edits.length) {
      await request('config/batchWrite', { edits, expectedVersion: layer.version, reloadUserConfig: true });
    }
    const { config } = edits.length ? await request('config/read', { includeLayers: false }) : read;
    if (config?.model_provider === providerId && config?.model_providers?.[providerId]?.base_url === gateway) {
      throw new ConfigurationError('Outra camada do Codex ainda seleciona AitoTokens. Revise o provedor na configuração do Codex e tente novamente.');
    }
    await unlink(file).catch(error => { if (error.code !== 'ENOENT') throw error; });
    return 'restored';
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const [command, powerShell, credentialScript, switchProvider, operation, ...prefix] = process.argv.slice(2);
    if (!command || !powerShell || !credentialScript) {
      throw new ConfigurationError('Execute este configurador pelo iniciador AitoIA.');
    }
    const status = operation === 'restore' ? await restore(command, prefix) : await configure({
      command,
      powerShell,
      credentialScript,
      switchProvider: switchProvider === 'yes',
      checkOnly: operation === 'check',
      prefix,
    });
    process.stdout.write(status + '\n');
  } catch (error) {
    process.stdout.write((error instanceof ConfigurationError
      ? error.message
      : 'Não foi possível configurar o Codex. Confira a instalação do aplicativo e do Node.js.') + '\n');
    process.exitCode = 1;
  }
}
