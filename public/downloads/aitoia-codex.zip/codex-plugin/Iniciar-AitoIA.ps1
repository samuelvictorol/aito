[CmdletBinding()]
param(
    [switch]$SetupOnly,
    [switch]$CreateShortcut,
    [switch]$Shortcut,
    [switch]$ReplaceKey,
    [switch]$UseAitoProvider,
    [string]$ProjectDirectory
)

$ErrorActionPreference = 'Stop'
$marketplaceName = 'aitosoftwares-pilot'
$pluginId = "aitosoftwares@$marketplaceName"
$packageRoot = (Get-Item -LiteralPath $PSScriptRoot).FullName
$powerShellPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$credentialPath = Join-Path $packageRoot 'plugin\AitoCredential.ps1'
$configurationPath = Join-Path $packageRoot 'Configurar-AitoCodex.mjs'

function Find-AitoCodex {
    $candidates = @()
    if ($env:LOCALAPPDATA) {
        $desktopBin = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
        if (Test-Path -LiteralPath $desktopBin -PathType Container) {
            $candidates += Join-Path $desktopBin 'codex.exe'
            $candidates += Get-ChildItem -LiteralPath $desktopBin -Directory |
                Sort-Object LastWriteTime -Descending | ForEach-Object { Join-Path $_.FullName 'codex.exe' }
        }
        $candidates += Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\codex.exe'
    }
    $candidates += @(Get-Command codex.exe, codex.cmd -CommandType Application -All -ErrorAction SilentlyContinue |
        Select-Object -ExpandProperty Source)
    if ($env:APPDATA) { $candidates += Join-Path $env:APPDATA 'npm\codex.cmd' }
    if ($env:ProgramFiles) { $candidates += Join-Path $env:ProgramFiles 'nodejs\codex.cmd' }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (!(Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $version = & $candidate --version
            if ($LASTEXITCODE -ne 0 -or $version -notmatch '^codex-cli ') { continue }
            $appHelp = & $candidate app --help | Out-String
            if ($LASTEXITCODE -eq 0 -and $appHelp -match '(?m)^Usage: codex app\b') { return $candidate }
        } catch { continue }
    }
    throw 'Instale ou atualize o aplicativo grafico do Codex em https://openai.com/codex/ e abra o iniciador novamente.'
}

function Find-AitoNode {
    $node = Get-Command node.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($node) {
        $version = & $node.Source --version
        if ($LASTEXITCODE -eq 0 -and $version -match '^v(\d+)\.' -and [int]$Matches[1] -ge 20) {
            return $node.Source
        }
    }
    throw 'Instale ou atualize o Node.js para a versao 20 ou superior em https://nodejs.org. Confira node --version em uma nova janela e reabra o Codex.'
}

function Get-AitoConfigLauncher {
    if ([System.IO.Path]::GetExtension($script:codex) -ieq '.exe') {
        return @{ Command = $script:codex; Prefix = @() }
    }
    $npmScript = Join-Path (Split-Path -Parent $script:codex) 'node_modules\@openai\codex\bin\codex.js'
    if (!(Test-Path -LiteralPath $npmScript -PathType Leaf)) {
        throw 'A instalacao do Codex CLI parece incompleta. Atualize o aplicativo grafico ou reinstale o Codex CLI oficial.'
    }
    return @{ Command = $script:nodePath; Prefix = @($npmScript) }
}

function Invoke-AitoCodex {
    param([string[]]$Arguments)
    & $script:codex @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Falha no Codex CLI ao executar $($Arguments -join ' '). Confira a mensagem acima ou atualize o Codex."
    }
}

function Register-AitoPlugin {
    $manifestPath = Join-Path $packageRoot 'plugin\.codex-plugin\plugin.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.name -ne 'aitosoftwares') { throw 'O ZIP precisa ser extraido por completo.' }

    $marketplaces = Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'list', '--json') |
        Out-String | ConvertFrom-Json
    $existing = $marketplaces.marketplaces | Where-Object { $_.name -eq $marketplaceName } | Select-Object -First 1
    if ($existing.root -eq $packageRoot) {
        $plugins = Invoke-AitoCodex -Arguments @('plugin', 'list', '--json') | Out-String | ConvertFrom-Json
        $installed = $plugins.installed | Where-Object { $_.pluginId -eq $pluginId } | Select-Object -First 1
        if ($installed.enabled -and $installed.version -eq $manifest.version) { return }
    }
    if ($existing -and $existing.root -ne $packageRoot) {
        Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'remove', $marketplaceName) | Out-Host
        try {
            Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'add', $packageRoot) | Out-Host
        } catch {
            if ($existing.root -and (Test-Path -LiteralPath $existing.root -PathType Container)) {
                & $script:codex plugin marketplace add $existing.root | Out-Host
            }
            throw
        }
    } elseif (!$existing) {
        Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'add', $packageRoot) | Out-Host
    }
    $install = Invoke-AitoCodex -Arguments @('plugin', 'add', '--json', $pluginId) | Out-String | ConvertFrom-Json
    if ($install.version -ne $manifest.version) {
        throw "O Codex instalou $($install.version) em vez de $($manifest.version). Confira o marketplace $marketplaceName."
    }
    Write-Host "Plugin AitoIA $($install.version) instalado." -ForegroundColor Cyan
}

function Set-AitoAppProvider {
    param([switch]$AllowSwitch, [switch]$CheckOnly)
    $launcher = Get-AitoConfigLauncher
    $allow = if ($AllowSwitch) { 'yes' } else { 'no' }
    $operation = if ($CheckOnly) { 'check' } else { 'write' }
    $arguments = @($configurationPath, $launcher.Command, $powerShellPath, $credentialPath, $allow, $operation) + $launcher.Prefix
    $result = & $script:nodePath @arguments | Out-String
    if ($LASTEXITCODE -ne 0) { throw $result.Trim() }
    return $result.Trim()
}

function New-AitoShortcut {
    param([string]$DesktopDirectory = [Environment]::GetFolderPath('DesktopDirectory'))
    if (!$DesktopDirectory -or !(Test-Path -LiteralPath $DesktopDirectory -PathType Container)) {
        throw 'Area de Trabalho indisponivel.'
    }
    $shortcutFile = Join-Path $DesktopDirectory 'AitoIA - Codex.lnk'
    $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($shortcutFile)
    $shortcut.TargetPath = $powerShellPath
    $shortcut.Arguments = '-NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy RemoteSigned -File "' +
        (Join-Path $packageRoot 'Iniciar-AitoIA.ps1') + '" -Shortcut'
    $shortcut.WorkingDirectory = $packageRoot
    $shortcut.IconLocation = (Join-Path $packageRoot 'AitoSoftwares.ico') + ',0'
    $shortcut.Description = 'AitoIA by AitoSoftwares'
    $shortcut.Save()
    Write-Host 'Atalho AitoIA - Codex criado na Area de Trabalho.' -ForegroundColor Cyan
}

function Test-AitoDesktopIsRunning {
    $runningApp = Get-Process -Name 'ChatGPT', 'Codex' -ErrorAction SilentlyContinue |
        Where-Object { $_.Path -match '\\OpenAI\.(Codex|ChatGPT)_[^\\]+\\' } | Select-Object -First 1
    return [bool]$runningApp
}

try {
    $originalEncoding = [Console]::OutputEncoding
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    if (!(Test-Path -LiteralPath $credentialPath -PathType Leaf) -or
        !(Test-Path -LiteralPath $configurationPath -PathType Leaf)) {
        throw 'Extraia o ZIP inteiro em uma pasta permanente antes de iniciar.'
    }
    $script:nodePath = Find-AitoNode
    $script:codex = Find-AitoCodex
    $configured = Set-AitoAppProvider -CheckOnly -AllowSwitch:$UseAitoProvider
    Register-AitoPlugin
    if ($CreateShortcut -or (!$SetupOnly -and !$Shortcut)) { New-AitoShortcut }
    if ($SetupOnly) {
        Write-Host 'AitoIA pronto para configurar. Feche a janela aberta do Codex e inicie pelo atalho.' -ForegroundColor Cyan
        return
    }

    if (($configured -ne 'ready' -or $ReplaceKey) -and (Test-AitoDesktopIsRunning)) {
        throw 'Encerre o aplicativo Codex ou ChatGPT (use Sair no icone junto ao relogio do Windows, se necessario) e abra o atalho AitoIA - Codex novamente.'
    }

    $allowSwitch = $UseAitoProvider
    if ($configured -eq 'provider-conflict') {
        $notice = 'O Codex tem outro provedor personalizado ativo. Usar AitoTokens como provedor padrao do aplicativo?'
        Add-Type -AssemblyName System.Windows.Forms
        $consent = [System.Windows.Forms.MessageBox]::Show($notice, 'AitoIA - Codex', 'YesNo', 'Question', 'Button2')
        if ($consent -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $allowSwitch = $true
    }

    $appArguments = @('app')
    if ($ProjectDirectory) {
        $project = Get-Item -LiteralPath $ProjectDirectory.Trim().Trim('"')
        if (!$project.PSIsContainer -or $project.PSProvider.Name -ne 'FileSystem') {
            throw 'Escolha uma pasta existente do Windows.'
        }
        $appArguments += $project.FullName
    }

    $credentialMode = if ($ReplaceKey) { 'Replace' } else { 'Ensure' }
    & $credentialPath -Mode $credentialMode -Gui
    if ($configured -ne 'ready') {
        $configured = Set-AitoAppProvider -AllowSwitch:$allowSwitch
        if ($configured -notin @('ready', 'updated')) { throw 'Nao foi possivel confirmar a configuracao AitoTokens.' }
    }
    Invoke-AitoCodex -Arguments $appArguments | Out-Host
} catch [System.OperationCanceledException] {
    return
} catch {
    if ($Shortcut) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'AitoIA - Codex', 'OK', 'Error') | Out-Null
    }
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
    exit 1
} finally {
    if ($originalEncoding) { [Console]::OutputEncoding = $originalEncoding }
}
