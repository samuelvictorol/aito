[CmdletBinding()]
param(
    [switch]$SetupOnly,
    [switch]$CreateShortcut,
    [string]$ProjectDirectory
)

$ErrorActionPreference = 'Stop'
$marketplaceName = 'aitosoftwares-pilot'
$pluginId = "aitosoftwares@$marketplaceName"
$packageRoot = (Get-Item -LiteralPath $PSScriptRoot).FullName
$profileName = 'aito'

function Find-AitoCodex {
    $candidates = @(
        Get-Command codex.exe, codex.cmd -CommandType Application -All -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty Source
    )
    if ($env:LOCALAPPDATA) {
        $desktopBin = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
        if (Test-Path -LiteralPath $desktopBin -PathType Container) {
            $candidates += Join-Path $desktopBin 'codex.exe'
            $candidates += Get-ChildItem -LiteralPath $desktopBin -Directory |
                Sort-Object LastWriteTime -Descending | ForEach-Object { Join-Path $_.FullName 'codex.exe' }
        }
        $candidates += Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\codex.exe'
    }
    if ($env:APPDATA) { $candidates += Join-Path $env:APPDATA 'npm\codex.cmd' }
    if ($env:ProgramFiles) { $candidates += Join-Path $env:ProgramFiles 'nodejs\codex.cmd' }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (!(Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $version = & $candidate --version
            if ($LASTEXITCODE -eq 0 -and $version -match '^codex-cli ') { return $candidate }
        } catch { continue }
    }
    throw 'Codex CLI indisponivel. Instale pelo site https://openai.com/codex/ ou rode npm.cmd install -g @openai/codex. Depois abra o iniciador novamente.'
}

function Invoke-AitoCodex {
    param([string[]]$Arguments)
    & $script:codex @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Falha no Codex CLI ao executar $($Arguments -join ' '). Confira a mensagem acima ou atualize o Codex."
    }
}

function Register-AitoPlugin {
    $manifestPath = Join-Path $packageRoot 'plugin\.codex-plugin\plugin.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.name -ne 'aitosoftwares') { throw 'O ZIP precisa ser extraido por completo.' }

    $marketplaces = Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'list', '--json') |
        Out-String | ConvertFrom-Json
    $existing = $marketplaces.marketplaces | Where-Object { $_.name -eq $marketplaceName } | Select-Object -First 1
    if ($existing -and $existing.root -ne $packageRoot) {
        Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'remove', $marketplaceName) | Out-Host
        try {
            Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'add', $packageRoot) | Out-Host
        } catch {
            if ($existing.root -and (Test-Path -LiteralPath $existing.root -PathType Container)) {
                & $script:codex plugin marketplace add $existing.root | Out-Host
            }
            throw
        }
    } elseif (!$existing) {
        Invoke-AitoCodex -Arguments @('plugin', 'marketplace', 'add', $packageRoot) | Out-Host
    }
    $install = Invoke-AitoCodex -Arguments @('plugin', 'add', '--json', $pluginId) | Out-String | ConvertFrom-Json
    if ($install.version -ne $manifest.version) {
        throw "O Codex instalou $($install.version) em vez de $($manifest.version). Confira o marketplace $marketplaceName."
    }
    Write-Host "Plugin AitoIA $($install.version) instalado." -ForegroundColor Cyan
}

function Set-AitoProfile {
    $codexDirectory = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
    New-Item -ItemType Directory -Force -Path $codexDirectory | Out-Null
    $template = Join-Path $packageRoot "$profileName.config.toml"
    $target = Join-Path $codexDirectory "$profileName.config.toml"
    if (!(Test-Path -LiteralPath $target)) {
        Copy-Item -LiteralPath $template -Destination $target
        return
    }
    $profileText = (Get-Content -LiteralPath $target -Raw).Replace("`r`n", "`n").Trim()
    $templateText = (Get-Content -LiteralPath $template -Raw).Replace("`r`n", "`n").Trim()
    if ($profileText -eq $templateText) { return }
    if ($profileText -eq ($templateText -replace '(?m)^model_reasoning_effort = "xhigh"\n', '')) {
        Copy-Item -LiteralPath $template -Destination $target -Force
        return
    }
    throw "O perfil aito existente em $target tem personalizacoes. Compare com $template, preserve suas escolhas e confirme que o provedor AitoTokens e a exclusao da chave continuam configurados antes de iniciar."
}

function New-AitoShortcut {
    $desktop = [Environment]::GetFolderPath('DesktopDirectory')
    if (!$desktop -or !(Test-Path -LiteralPath $desktop -PathType Container)) { throw 'Area de Trabalho indisponivel.' }
    $shortcutFile = Join-Path $desktop 'AitoIA - Codex.lnk'
    $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($shortcutFile)
    $shortcut.TargetPath = Join-Path $packageRoot 'Iniciar AitoIA.bat'
    $shortcut.WorkingDirectory = $packageRoot
    $shortcut.IconLocation = (Join-Path $packageRoot 'AitoSoftwares.ico') + ',0'
    $shortcut.Description = 'AitoIA by AitoSoftwares'
    $shortcut.Save()
    Write-Host 'Atalho AitoIA - Codex criado na Area de Trabalho.' -ForegroundColor Cyan
}

try {
    Write-Host 'AitoIA by AitoSoftwares | Codex local' -ForegroundColor Cyan
    $script:codex = Find-AitoCodex
    $node = Get-Command node.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (!$node) {
        $nodePath = if ($env:ProgramFiles) { Join-Path $env:ProgramFiles 'nodejs\node.exe' }
        if ($nodePath -and (Test-Path -LiteralPath $nodePath -PathType Leaf)) {
            $env:Path = (Split-Path -Parent $nodePath) + ';' + $env:Path
            $node = Get-Command node.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        }
    }
    $nodeVersion = if ($node) { & $node.Source --version }
    if (!$node -or $LASTEXITCODE -ne 0 -or $nodeVersion -notmatch '^v([2-9][0-9]|[1-9][0-9]{2,})\.') {
        throw 'Instale o Node.js 20 ou superior em https://nodejs.org e abra o iniciador novamente.'
    }
    Set-AitoProfile
    Register-AitoPlugin
    if ($CreateShortcut) { New-AitoShortcut }
    if ($SetupOnly) { return }

    $codexHelp = & $script:codex --help | Out-String
    if ($codexHelp -notmatch '(?m)^\s*--no-daemon\b') {
        throw 'Atualize o Codex CLI para iniciar uma sessao local com a chave desta janela.'
    }
    if (!$ProjectDirectory) {
        $ProjectDirectory = Read-Host 'Pasta do projeto (Enter para abrir uma pasta separada de teste)'
        if (!$ProjectDirectory) {
            $ProjectDirectory = Join-Path $env:LOCALAPPDATA 'AitoSoftwares\CodexWorkspace'
            New-Item -ItemType Directory -Force -Path $ProjectDirectory | Out-Null
        }
    }
    $project = Get-Item -LiteralPath $ProjectDirectory.Trim().Trim('"')
    if (!$project.PSIsContainer -or $project.PSProvider.Name -ne 'FileSystem') { throw 'Escolha uma pasta existente do Windows.' }

    Write-Host 'Gere sua AitoKey em https://aitosoftwares.com/app?tab=profile > Meus dados.'
    $secret = Read-Host 'AitoKey (oculta)' -AsSecureString
    $originalKey = $env:AITO_CODEX_API_KEY
    try {
        $env:AITO_CODEX_API_KEY = [System.Net.NetworkCredential]::new('', $secret).Password.Trim()
        if ($env:AITO_CODEX_API_KEY -cnotmatch '\Aaito_(?:usr|prj)_[A-Za-z0-9_-]{48}\z') {
            throw 'Formato de AitoKey invalido. Copie a chave pessoal completa de Meus dados.'
        }
        Write-Host 'Use /status no Codex para confirmar o provedor AitoTokens.' -ForegroundColor Cyan
        Invoke-AitoCodex -Arguments @('--no-daemon', '--profile', $profileName, '--cd', $project.FullName)
    } finally {
        $env:AITO_CODEX_API_KEY = $originalKey
        $secret.Dispose()
    }
} catch {
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
    exit 1
}
