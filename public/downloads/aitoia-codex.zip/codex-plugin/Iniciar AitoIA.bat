@echo off
if not exist "%~dp0Iniciar AitoIA.exe" (
  echo Extraia o ZIP oficial inteiro para usar Iniciar AitoIA.exe.
  exit /b 1
)
"%~dp0Iniciar AitoIA.exe" %*
exit /b %errorlevel%
