@echo off
setlocal
title AitoIA by AitoSoftwares
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Iniciar-AitoIA.ps1" %*
set "AITO_EXIT_CODE=%errorlevel%"
if not "%AITO_EXIT_CODE%"=="0" pause
exit /b %AITO_EXIT_CODE%
