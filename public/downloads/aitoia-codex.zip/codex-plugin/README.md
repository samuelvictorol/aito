# AitoIA by AitoSoftwares · 0.2.3

Use GPT‑6.1 Sol no Codex com os AitoTokens da sua conta. O perfil `aito` conecta a sua AitoKey, e o plugin permite consultar saldo, acompanhar o consumo e recarregar a carteira na conversa. Quando o vídeo está habilitado, a mesma chave dá acesso às ferramentas da Higgsfield.

[Site da AitoSoftwares](https://aitosoftwares.com) · [Instagram @aitosoftwares](https://www.instagram.com/aitosoftwares/) · [Suporte](https://aitosoftwares.com/#contato)

## Windows em três passos

1. Extraia o ZIP inteiro para uma pasta que você queira manter. Instale o [Codex CLI](https://learn.chatgpt.com/docs/cli/quickstart) e o [Node.js 20 ou superior](https://nodejs.org/) se estiverem faltando.
2. Em [Meus dados](https://aitosoftwares.com/app?tab=profile), abra **AitoKey para Codex**, escolha a carteira e clique em **Gerar AitoKey**. Guarde a chave, que é exibida uma vez. Em caso de perda ou exposição, **Regenerar AitoKey** invalida a anterior e preserva o saldo.
3. Na pasta `codex-plugin`, abra **Iniciar AitoIA.bat**. Escolha a pasta do projeto e cole a chave somente no prompt oculto. No Codex, digite `/status` e confira o provedor AitoTokens. A partir daí, converse normalmente e use o plugin quando quiser consultar saldo, recarregar ou cotar um vídeo.

O iniciador localiza o CLI mesmo quando o comando `codex` não está no PATH, usando instalações conhecidas do aplicativo ou do npm. O perfil local usa a chave da carteira AitoTokens e pode funcionar sem assinatura Pro. Os menus, modelos e controles que o Codex exibe seguem as capacidades da versão instalada.

Se preferir que o Codex faça a configuração, abra a pasta extraída nele e envie **“Configure para mim este plugin AitoIA. Siga o arquivo CONFIGURAR-COM-CODEX.txt.”** Para configurar sem abrir uma sessão, rode `.\Iniciar-AitoIA.ps1 -SetupOnly`. Acrescente `-CreateShortcut` para criar o atalho **AitoIA - Codex** com a logo da AitoSoftwares.

Para atualizar no Windows, baixe o ZIP atual, extraia e abra o iniciador dessa versão. Ele registra o novo pacote e confere a versão instalada. Se o perfil `aito` foi personalizado, compare-o com o arquivo do pacote antes de alterar suas preferências.

Se o Windows marcar o ZIP como arquivo da internet, confira a origem do download. Em um PC pessoal, use **Propriedades → Desbloquear** no ZIP oficial antes de extrair novamente, se a opção estiver disponível. Em um PC gerenciado, siga a política da organização.

## Instalação manual

1. Entre na AitoSoftwares e abra [Meus dados](https://aitosoftwares.com/app?tab=profile). Em **AitoKey para Codex**, selecione a carteira e clique em **Gerar AitoKey**. Copie ou baixe a chave, que é exibida uma vez. Se a chave vazar ou for perdida, use **Regenerar AitoKey**. Isso invalida a chave anterior e preserva o saldo na carteira.
2. Instale o [Codex](https://openai.com/codex/) e o Node.js 20 ou superior. Use uma versão do Codex que reconheça `gpt-6.1-sol`.
3. Distribua apenas esta pasta `codex-plugin`, incluindo as pastas ocultas `.agents` e `plugin/.codex-plugin`. O diretório do plugin funciona sem dependências externas.
4. No PowerShell, a partir da pasta distribuída, adicione o marketplace e o plugin:

   ```powershell
   codex plugin marketplace add .
   codex plugin add aitosoftwares@aitosoftwares-pilot
   ```

   Depois que o marketplace estiver disponível na máquina, o [link de instalação no Codex](codex://plugins/install/aitosoftwares?marketplace=aitosoftwares-pilot) abre a tela de instalação do aplicativo. O Codex pode exigir aprovação do administrador em ambientes corporativos.

   Se você já instalou a versão anterior, atualize a pasta local e reinstale o plugin com `codex plugin remove aitosoftwares@aitosoftwares-pilot` e `codex plugin add aitosoftwares@aitosoftwares-pilot`. Inicie uma nova sessão.

## Iniciar uma sessão local manualmente

Copie `aito.config.toml` para `%USERPROFILE%\.codex\aito.config.toml` no Windows ou para `~/.codex/aito.config.toml` no macOS e Linux. Use o perfil `aito` em uma nova sessão. Ele seleciona o provedor Aito e deixa a chave fora do ambiente repassado aos comandos que o agente executa.

No Windows, inicie o Codex CLI a partir do repositório em que você quer trabalhar. O prompt do PowerShell protege a digitação e a variável existe apenas na sessão local:

```powershell
$aitoCodexSecret = Read-Host 'AitoKey' -AsSecureString
$env:AITO_CODEX_API_KEY = [System.Net.NetworkCredential]::new('', $aitoCodexSecret).Password
try {
  codex --no-daemon --profile aito
} finally {
  Remove-Item Env:AITO_CODEX_API_KEY -ErrorAction SilentlyContinue
  $aitoCodexSecret.Dispose()
}
```

Para usar o aplicativo oficial, abra **Configurações → Configuração** e incorpore as seções do exemplo à configuração do usuário. Mantenha as regras de exclusão de variáveis que já estiverem configuradas. O processo do aplicativo precisa receber `AITO_CODEX_API_KEY` pelo ambiente gerenciado da organização ou por um iniciador que a disponibilize ao processo. Reinicie o aplicativo após configurar o provedor. Veja a [configuração do Codex no Windows](https://learn.chatgpt.com/docs/enterprise/connect-to-a-gateway#configure-the-windows-app).

No Codex, confirme o provedor AitoTokens com `/status` e peça **“Consulte meu saldo AitoTokens”**. A skill `$aito-tokens` também pode ser selecionada no campo de composição. Cada sessão usa os limites, permissões e conectores do cliente Codex.

O perfil inicia com GPT‑6.1 Sol e esforço extra alto. Quando habilitado no gateway, o CLI permite selecionar outro modelo com `--model`, ajustar esforço com `-c 'model_reasoning_effort="high"'` e selecionar velocidade rápida com `-c 'service_tier="fast"'` nos modelos que oferecem tarifa Priority. Use os níveis de esforço compatíveis com o modelo selecionado.

O botão **Testar agora** usa a sessão do aplicativo que já está aberta. A chave temporária do PowerShell é herdada apenas pelo processo iniciado a partir dele. Use o plugin nessa sessão ou feche completamente o aplicativo antes de iniciá-lo pelo ambiente que contém a chave.

O perfil usa ferramentas e compactação locais. O limite de entrada é 160 mil tokens. A API reserva o valor antes da chamada e aplica o multiplicador vigente ao consumo confirmado. Uma interrupção com consumo desconhecido pode aparecer para conciliação no painel AitoTokens.

## Gerar vídeo Higgsfield com a mesma AitoKey

O catálogo do plugin mostra os modelos e opções de vídeo a partir de texto quando o recurso está habilitado. Os pedidos pagos com AitoTokens usam as ferramentas de vídeo do plugin AitoSoftwares.

1. Peça no Codex **“Use a ferramenta AitoSoftwares para cotar um vídeo Higgsfield com meus AitoTokens”** e descreva o vídeo.
2. Confira o preço em dólar e real. O Codex precisa oferecer confirmações MCP. Autorize o débito na confirmação exibida pelo Codex para iniciar a geração.
3. Guarde o ID da geração exibido na cotação para consultar o vídeo na mesma conversa ou depois. Se a solicitação for interrompida ou o status continuar em fila, consulte esse ID antes de pedir outra geração. Ao concluir, abra o link para assistir ou baixar.

Antes da distribuição comercial, valide o uso proposto com a Higgsfield. Os [termos da API](https://open.higgsfield.ai/terms-of-service#restrictions-anti-resale-end-users) restringem a revenda da API como serviço independente ou equivalente. A chave do provedor permanece no servidor. Os participantes usam apenas a AitoKey.

## Acompanhar o piloto no admin

Abra **AitoTokens → Uso e custos** para filtrar por origem, provedor e período. Compare o débito AitoTokens, o custo do provedor e a margem bruta em dólar e real. OpenAI registra tokens. Higgsfield registra a unidade da geração e o custo cotado. Consulte a requisição pelo ID do lançamento ao conferir uma reserva ou uma conciliação. A margem bruta considera a diferença entre o débito e o custo do provedor, antes de taxas, impostos e despesas operacionais.

## Recargas e suporte

A ferramenta de recarga gera um link da InfinitePay mediante pedido e confirmação do pacote. O pagamento é concluído pelo usuário. A carteira é atualizada após a confirmação da InfinitePay. Use a ferramenta de saldo quando houver um aviso de crédito insuficiente ou uma nova recarga.

Com a carteira zerada, consulte o saldo e gere o link pelo terminal usando a mesma variável local, a partir da pasta distribuída. Esses comandos acessam a carteira diretamente.

```powershell
node carteira.mjs saldo
node carteira.mjs recarregar 5
```

A AitoKey fica no ambiente da sessão e é removida quando o iniciador termina. Se a credencial for exposta, regenere-a em **Meus dados**. A conta comercial e o catálogo de modelos da Aito são gerenciados no servidor.
