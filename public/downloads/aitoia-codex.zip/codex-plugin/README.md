# AitoIA - by AitoSoftwares · piloto 2.0.0

Pacote local com o nome de distribuição solicitado, baseado na integração 0.2.0. O projeto ainda precisa estar autorizado para o piloto. Este arquivo ZIP é instalado pelo marketplace local do Codex.

O perfil `aito` usa o provedor AitoTokens para conversar com o modelo OpenAI no Codex local. A mesma AitoKey de projeto autoriza a geração de vídeo Higgsfield pelas ferramentas do plugin AitoSoftwares. A carteira mostra saldo em dólar e real, estimativa de tokens, consumo dos últimos 30 dias e recargas.

## Preparação do piloto

1. O administrador da AitoSoftwares emite uma AitoKey para um projeto ativo por participante, configura a chave OpenAI no servidor e ativa `AITO_CODEX_ENABLED=true` na API. Inclua os IDs autorizados em `AITO_CODEX_PROJECT_IDS`, separados por vírgulas. A rotação da AitoKey preserva a carteira. Compartilhe a credencial por um canal privado. Chaves compartilhadas identificam o projeto, portanto use uma por participante para atribuir o consumo individualmente.
2. Cada participante instala o [Codex](https://openai.com/codex/) e o Node.js 20 ou superior. Use uma versão do Codex que reconheça `gpt-6.1-sol`.
3. Distribua apenas esta pasta `codex-plugin`, incluindo as pastas ocultas `.agents` e `plugin/.codex-plugin`. O diretório do plugin funciona sem dependências externas.
4. No PowerShell, a partir da pasta distribuída, adicione o marketplace e o plugin:

   ```powershell
   codex plugin marketplace add .
   codex plugin add aitosoftwares@aitosoftwares-pilot
   ```

   Depois que o marketplace estiver disponível na máquina, o [link de instalação no Codex](codex://plugins/install/aitosoftwares?marketplace=aitosoftwares-pilot) abre a tela de instalação do aplicativo. O Codex pode exigir aprovação do administrador em ambientes corporativos.

   Se você já instalou a versão anterior, atualize a pasta local e reinstale o plugin com `codex plugin remove aitosoftwares@aitosoftwares-pilot` e `codex plugin add aitosoftwares@aitosoftwares-pilot`. Inicie uma nova sessão.

## Iniciar uma sessão local

Copie `aito.config.toml` para `%USERPROFILE%\.codex\aito.config.toml` no Windows ou para `~/.codex/aito.config.toml` no macOS e Linux. Use o perfil `aito` em uma nova sessão. Ele seleciona o provedor Aito e deixa a chave fora do ambiente repassado aos comandos que o agente executa.

No Windows, inicie o Codex CLI a partir do repositório em que você quer trabalhar. O prompt do PowerShell protege a digitação e a variável existe apenas na sessão local:

```powershell
$aitoCodexSecret = Read-Host 'AitoKey' -AsSecureString
$env:AITO_CODEX_API_KEY = [System.Net.NetworkCredential]::new('', $aitoCodexSecret).Password
try {
  codex --profile aito
} finally {
  Remove-Item Env:AITO_CODEX_API_KEY -ErrorAction SilentlyContinue
  $aitoCodexSecret.Dispose()
}
```

Para usar o aplicativo oficial, abra **Configurações → Configuração** e incorpore as seções do exemplo à configuração do usuário. Mantenha as regras de exclusão de variáveis que já estiverem configuradas. O processo do aplicativo precisa receber `AITO_CODEX_API_KEY` pelo ambiente gerenciado da organização ou por um iniciador que a disponibilize ao processo. Reinicie o aplicativo após configurar o provedor. Veja a [configuração do Codex no Windows](https://learn.chatgpt.com/docs/enterprise/connect-to-a-gateway#configure-the-windows-app).

No Codex, confirme o provedor AitoTokens com `/status` e peça **“Consulte meu saldo AitoTokens”**. A skill `$aito-tokens` também pode ser selecionada no campo de composição. Cada sessão usa os limites, permissões e conectores do cliente Codex.

O piloto usa GPT‑6.1 Sol com transmissão HTTP, ferramentas locais e compactação local configurada no perfil. O limite de entrada do provedor é 160 mil tokens. A API reserva o valor antes da chamada e aplica ao consumo confirmado o multiplicador vigente no início da operação. Em caso de interrupção com consumo desconhecido, a reserva pode aparecer para conciliação no painel AitoTokens.

## Gerar vídeo Higgsfield com a mesma AitoKey

O administrador habilita `AITO_CODEX_HIGGSFIELD_ENABLED=true` separadamente, com a chave Higgsfield configurada na API da AitoSoftwares. A integração do piloto oferece vídeo a partir de texto com os modelos e opções apresentados no catálogo do plugin. O [MCP oficial da Higgsfield](https://higgsfield.ai/creator-hub/help-center/integrations/what-is-higgsfield-mcp) usa a conta e os créditos da própria Higgsfield, por isso os pedidos pagos com AitoTokens devem usar as ferramentas do plugin AitoSoftwares.

1. Peça no Codex **“Use a ferramenta AitoSoftwares para cotar um vídeo Higgsfield com meus AitoTokens”** e descreva o vídeo.
2. Confira o preço em dólar e real. O Codex precisa oferecer confirmações MCP. Autorize o débito na confirmação exibida pelo Codex para iniciar a geração.
3. Guarde o ID da geração exibido na cotação para consultar o vídeo na mesma conversa ou depois. Se a solicitação for interrompida ou o status continuar em fila, consulte esse ID antes de pedir outra geração. Ao concluir, abra o link para assistir ou baixar.

Antes da distribuição comercial, valide o uso proposto com a Higgsfield. Os [termos da API](https://open.higgsfield.ai/terms-of-service#restrictions-anti-resale-end-users) restringem a revenda da API como serviço independente ou equivalente. A chave do provedor permanece no servidor. Os participantes usam apenas a AitoKey.

## Acompanhar o piloto no admin

Abra **AitoTokens → Uso e custos** para filtrar por origem, provedor e período. Compare o débito AitoTokens, o custo do provedor e a margem bruta em dólar e real. OpenAI registra tokens. Higgsfield registra a unidade da geração e o custo cotado. Consulte a requisição pelo ID do lançamento ao conferir uma reserva ou uma conciliação. A margem bruta considera a diferença entre o débito e o custo do provedor, antes de taxas, impostos e despesas operacionais.

## Recargas e suporte

A ferramenta de recarga gera um link da InfinitePay mediante pedido e confirmação do pacote. O pagamento é concluído pelo usuário. A carteira é atualizada após a confirmação da InfinitePay. Use a ferramenta de saldo quando houver um aviso de crédito insuficiente ou uma nova recarga.

Com a carteira zerada, consulte o saldo e gere o link pelo terminal usando a mesma variável local, a partir da pasta distribuída. Esses comandos acessam a carteira diretamente.

```powershell
node carteira.mjs saldo
node carteira.mjs recarregar 5
```

A AitoKey fica no ambiente da sessão. Se a credencial for exposta, o administrador pode rotacioná-la. A conta comercial e o catálogo de modelos da Aito são gerenciados no servidor.
