# AitoIA by AitoSoftwares · 0.2.2

Use GPT‑6.1 Sol no Codex com os AitoTokens da sua conta. O perfil `aito` conecta a sua AitoKey, e o plugin permite consultar saldo, acompanhar o consumo e recarregar a carteira na conversa. Quando o vídeo está habilitado, a mesma chave dá acesso às ferramentas da Higgsfield.

[Site da AitoSoftwares](https://aitosoftwares.com) · [Instagram @aitosoftwares](https://www.instagram.com/aitosoftwares/) · [Suporte](https://aitosoftwares.com/#contato)

## Instalação

1. Entre na AitoSoftwares e abra [Meus dados](https://aitosoftwares.com/app?tab=profile). Em **AitoKey para Codex**, selecione a carteira e clique em **Gerar AitoKey**. Copie ou baixe a chave, que é exibida uma vez. Se a chave vazar ou for perdida, use **Regenerar AitoKey**. Isso invalida a chave anterior e preserva o saldo na carteira.
2. Instale o [Codex](https://openai.com/codex/) e o Node.js 20 ou superior. Use uma versão do Codex que reconheça `gpt-6.1-sol`.
3. Distribua apenas esta pasta `codex-plugin`, incluindo as pastas ocultas `.agents` e `plugin/.codex-plugin`. O diretório do plugin funciona sem dependências externas.
4. No PowerShell, a partir da pasta distribuída, adicione o marketplace e o plugin:

   ```powershell
   codex plugin marketplace add .
   codex plugin add aitosoftwares@aitosoftwares-pilot
   ```

   Depois que o marketplace estiver disponível na máquina, o [link de instalação no Codex](codex://plugins/install/aitosoftwares?marketplace=aitosoftwares-pilot) abre a tela de instalação do aplicativo. O Codex pode exigir aprovação do administrador em ambientes corporativos.

   Se você já instalou a versão anterior, atualize a pasta local e reinstale o plugin com `codex plugin remove aitosoftwares@aitosoftwares-pilot` e `codex plugin add aitosoftwares@aitosoftwares-pilot`. Inicie uma nova sessão.

## Iniciar uma sessão local

Copie `aito.config.toml` para `%USERPROFILE%\.codex\aito.config.toml` no Windows ou para `~/.codex/aito.config.toml` no macOS e Linux. Use o perfil `aito` em uma nova sessão. Ele seleciona o provedor Aito e deixa a chave fora do ambiente repassado aos comandos que o agente executa.

No Windows, inicie o Codex CLI a partir do repositório em que você quer trabalhar. O prompt do PowerShell protege a digitação e a variável existe apenas na sessão local:

```powershell
$aitoCodexSecret = Read-Host 'AitoKey' -AsSecureString
$env:AITO_CODEX_API_KEY = [System.Net.NetworkCredential]::new('', $aitoCodexSecret).Password
try {
  codex --profile aito
} finally {
  Remove-Item Env:AITO_CODEX_API_KEY -ErrorAction SilentlyContinue
  $aitoCodexSecret.Dispose()
}
```

Para usar o aplicativo oficial, abra **Configurações → Configuração** e incorpore as seções do exemplo à configuração do usuário. Mantenha as regras de exclusão de variáveis que já estiverem configuradas. O processo do aplicativo precisa receber `AITO_CODEX_API_KEY` pelo ambiente gerenciado da organização ou por um iniciador que a disponibilize ao processo. Reinicie o aplicativo após configurar o provedor. Veja a [configuração do Codex no Windows](https://learn.chatgpt.com/docs/enterprise/connect-to-a-gateway#configure-the-windows-app).

No Codex, confirme o provedor AitoTokens com `/status` e peça **“Consulte meu saldo AitoTokens”**. A skill `$aito-tokens` também pode ser selecionada no campo de composição. Cada sessão usa os limites, permissões e conectores do cliente Codex.

O piloto usa GPT‑6.1 Sol com transmissão HTTP, ferramentas locais e compactação local configurada no perfil. O limite de entrada do provedor é 160 mil tokens. A API reserva o valor antes da chamada e aplica ao consumo confirmado o multiplicador vigente no início da operação. Em caso de interrupção com consumo desconhecido, a reserva pode aparecer para conciliação no painel AitoTokens.

## Gerar vídeo Higgsfield com a mesma AitoKey

O catálogo do plugin mostra os modelos e opções de vídeo a partir de texto quando o recurso está habilitado. Os pedidos pagos com AitoTokens usam as ferramentas de vídeo do plugin AitoSoftwares.

1. Peça no Codex **“Use a ferramenta AitoSoftwares para cotar um vídeo Higgsfield com meus AitoTokens”** e descreva o vídeo.
2. Confira o preço em dólar e real. O Codex precisa oferecer confirmações MCP. Autorize o débito na confirmação exibida pelo Codex para iniciar a geração.
3. Guarde o ID da geração exibido na cotação para consultar o vídeo na mesma conversa ou depois. Se a solicitação for interrompida ou o status continuar em fila, consulte esse ID antes de pedir outra geração. Ao concluir, abra o link para assistir ou baixar.

Antes da distribuição comercial, valide o uso proposto com a Higgsfield. Os [termos da API](https://open.higgsfield.ai/terms-of-service#restrictions-anti-resale-end-users) restringem a revenda da API como serviço independente ou equivalente. A chave do provedor permanece no servidor. Os participantes usam apenas a AitoKey.

## Acompanhar o piloto no admin

Abra **AitoTokens → Uso e custos** para filtrar por origem, provedor e período. Compare o débito AitoTokens, o custo do provedor e a margem bruta em dólar e real. OpenAI registra tokens. Higgsfield registra a unidade da geração e o custo cotado. Consulte a requisição pelo ID do lançamento ao conferir uma reserva ou uma conciliação. A margem bruta considera a diferença entre o débito e o custo do provedor, antes de taxas, impostos e despesas operacionais.

## Recargas e suporte

A ferramenta de recarga gera um link da InfinitePay mediante pedido e confirmação do pacote. O pagamento é concluído pelo usuário. A carteira é atualizada após a confirmação da InfinitePay. Use a ferramenta de saldo quando houver um aviso de crédito insuficiente ou uma nova recarga.

Com a carteira zerada, consulte o saldo e gere o link pelo terminal usando a mesma variável local, a partir da pasta distribuída. Esses comandos acessam a carteira diretamente.

```powershell
node carteira.mjs saldo
node carteira.mjs recarregar 5
```

A AitoKey fica no ambiente da sessão. Se a credencial for exposta, o administrador pode rotacioná-la. A conta comercial e o catálogo de modelos da Aito são gerenciados no servidor.
