# AitoIA · 0.2.5

Use os modelos GPT disponíveis no Codex com os AitoTokens da sua conta. O provedor AitoTokens conecta a sua AitoKey. O plugin permite consultar saldo, acompanhar o consumo e recarregar a carteira na conversa.

[AitoIA para Codex](https://aitosoftwares.com/aitoia-codex) · [Instagram @aitosoftwares](https://www.instagram.com/aitosoftwares/) · [Suporte](https://aitosoftwares.com/#contato)

## Windows em três passos

1. Extraia o ZIP inteiro em uma pasta que você possa manter. Instale o [app oficial do Codex para Windows](https://openai.com/codex/) e confira `node --version` em um PowerShell novo. O plugin precisa de [Node.js 20 ou superior](https://nodejs.org/) no PATH. Depois de atualizar o Node, feche e reabra o app.
2. Em [Meus dados](https://aitosoftwares.com/app?tab=profile), abra **AitoKey para Codex**, escolha a carteira e clique em **Gerar AitoKey**. Guarde a chave, que é exibida uma vez. Em caso de perda ou exposição, **Regenerar AitoKey** invalida a anterior e preserva o saldo.
3. Na pasta `codex-plugin`, abra **Iniciar AitoIA.bat**. O iniciador registra o plugin, cria **AitoIA - Codex** na Área de Trabalho e abre o app gráfico oficial. Na primeira abertura, informe a chave na janela local protegida. As próximas aberturas usam o Gerenciador de Credenciais do Windows.

O iniciador usa o comando oficial `codex app` e configura AitoTokens como provedor padrão do app. Salve o trabalho e feche o app antes de trocar de provedor. Em **Configurações → Configuração**, você pode selecionar o provedor desejado. Abra uma conversa nova após a troca. Os modelos disponíveis dependem da versão instalada, da configuração do app e do catálogo do gateway. [Codex CLI](https://learn.chatgpt.com/docs/cli/reference) · [Configurar o app Windows](https://learn.chatgpt.com/docs/enterprise/connect-to-a-gateway#configure-the-windows-app).

Se preferir que o Codex faça a configuração, abra a pasta extraída nele e envie **“Configure para mim este plugin AitoIA. Siga o arquivo CONFIGURAR-COM-CODEX.txt.”** Para preparar o atalho antes de abrir o app, rode `& '.\Iniciar AitoIA.bat' -SetupOnly -CreateShortcut`.

### Comandos rápidos

Digite `@` no campo de mensagem e selecione **AitoIA**. A skill `$aito-tokens` também está disponível no seletor.

| O que você quer | Como usar |
| --- | --- |
| Trocar modelo | Use o seletor de modelos do Codex. |
| Consultar carteira | “Consulte meu saldo de AitoTokens.” |
| Conferir gastos | “Mostre meu consumo recente de AitoTokens.” |
| Recarregar | “Mostre os pacotes de recarga de AitoTokens.” |
| Conferir versão | “Verifique se há uma atualização do AitoIA.” |
| Atualizar no Windows | “Abra o atualizador do AitoIA.” |

### Atualizar o AitoIA

No Windows, o atalho avisa quando há uma nova versão. Você também pode pedir **“Abra o atualizador do AitoIA”** no Codex ou abrir **Atualizar AitoIA.bat** na pasta do pacote. Após confirmar, o atualizador baixa e verifica o SHA-256 do ZIP oficial e mostra o novo **Iniciar AitoIA.bat** no Explorador. Salve o trabalho, encerre o Codex e abra o iniciador exibido. Ele atualiza o plugin e o atalho, e reutiliza a AitoKey do Gerenciador de Credenciais do Windows.

Quem ainda estiver na versão 0.2.4 ou inferior pode baixar o [ZIP atual](https://aitosoftwares.com/downloads/aitoia-codex.zip) uma vez e abrir o iniciador. Se você selecionou outro provedor personalizado, revise a troca antes de adotá-la.

Para trocar a credencial, gere outra em **Meus dados** e execute `& .\plugin\AitoCredential.ps1 -Mode Replace` a partir da pasta do pacote. Informe a nova chave localmente e reinicie o Codex.

### Paleta verde AitoIA

Em **Configurações → Aparência**, selecione base escura. Use `#5EEAD4` para destaque, `#092523` para fundo e `#DCF9F4` para texto. Use a opção de translucidez da barra lateral, se estiver disponível. [Aparência do app](https://learn.chatgpt.com/docs/app/settings#appearance).

O ícone do plugin AitoIA aparece na lista de plugins e no seletor de contexto. O menu nativo do provedor exibe o nome AitoTokens. A seleção do mascote fica em **Configurações → Pets**, onde um mascote personalizado usa uma folha de quadros PNG ou WebP. [Plugins](https://developers.openai.com/plugins/build/plugins) · [Mascotes do Codex](https://learn.chatgpt.com/docs/pets).

Se o Windows marcar o ZIP como arquivo da internet, confira a origem do download. Em um PC pessoal, use **Propriedades → Desbloquear** no ZIP oficial antes de extrair novamente, se a opção estiver disponível. Em um PC gerenciado, siga a política da organização.

## Instalação manual

1. Entre na AitoSoftwares e abra [Meus dados](https://aitosoftwares.com/app?tab=profile). Em **AitoKey para Codex**, selecione a carteira e clique em **Gerar AitoKey**. Copie ou baixe a chave, que é exibida uma vez. Se a chave vazar ou for perdida, use **Regenerar AitoKey**. Isso invalida a chave anterior e preserva o saldo na carteira.
2. Instale o [Codex](https://openai.com/codex/) e o Node.js 20 ou superior. Use uma versão do Codex que reconheça `gpt-6.1-sol`.
3. Distribua apenas esta pasta `codex-plugin`, incluindo as pastas ocultas `.agents` e `plugin/.codex-plugin`. O diretório do plugin funciona sem dependências externas.
4. No PowerShell, a partir da pasta distribuída, adicione o marketplace e o plugin:

   ```powershell
   codex plugin marketplace add .
   codex plugin add aitosoftwares@aitosoftwares-pilot
   ```

   Depois que o marketplace estiver disponível na máquina, o [link de instalação no Codex](codex://plugins/install/aitosoftwares?marketplace=aitosoftwares-pilot) abre a tela de instalação do aplicativo. O Codex pode exigir aprovação do administrador em ambientes corporativos.

   Se você já instalou a versão anterior, atualize a pasta local e reinstale o plugin com `codex plugin remove aitosoftwares@aitosoftwares-pilot` e `codex plugin add aitosoftwares@aitosoftwares-pilot`. Inicie uma nova sessão.

## Iniciar uma sessão local manualmente

Copie `aito.config.toml` para `%USERPROFILE%\.codex\aito.config.toml` no Windows ou para `~/.codex/aito.config.toml` no macOS e Linux. Use o perfil `aito` em uma nova sessão. Ele seleciona o provedor Aito e deixa a chave fora do ambiente repassado aos comandos que o agente executa.

No Windows, inicie o Codex CLI a partir do repositório em que você quer trabalhar. O prompt do PowerShell protege a digitação e a variável existe apenas na sessão local:

```powershell
$aitoCodexSecret = Read-Host 'AitoKey' -AsSecureString
$env:AITO_CODEX_API_KEY = [System.Net.NetworkCredential]::new('', $aitoCodexSecret).Password
try {
  codex --no-daemon --profile aito
} finally {
  Remove-Item Env:AITO_CODEX_API_KEY -ErrorAction SilentlyContinue
  $aitoCodexSecret.Dispose()
}
```

O iniciador do Windows usa a configuração de provedor com autenticação por auxiliar local. Para instalações manuais da CLI, mantenha a configuração por variável do exemplo. [Autenticação de provedores no Codex](https://learn.chatgpt.com/docs/config-file/config-reference).

No Codex, confirme o provedor AitoTokens com `/status` e peça **“Consulte meu saldo AitoTokens”**. A skill `$aito-tokens` também pode ser selecionada no campo de composição. Cada sessão usa os limites, permissões e conectores do cliente Codex.

O perfil inicia com GPT‑6.1 Sol e esforço extra alto. Quando habilitado no gateway, o CLI permite selecionar outro modelo com `--model`, ajustar esforço com `-c 'model_reasoning_effort="high"'` e selecionar velocidade rápida com `-c 'service_tier="fast"'` nos modelos que oferecem tarifa Priority. Use os níveis de esforço compatíveis com o modelo selecionado.

No Windows, as ferramentas do plugin consultam o Gerenciador de Credenciais. Abra uma conversa nova depois de instalar o plugin ou de alterar o provedor. No modo CLI manual, inicie a sessão no PowerShell que contém a chave temporária.

O perfil usa ferramentas e compactação locais. O limite de entrada é 160 mil tokens. A API reserva o valor antes da chamada e aplica o multiplicador vigente ao consumo confirmado. Uma interrupção com consumo desconhecido pode aparecer para conciliação no painel AitoTokens.

## Acompanhar o piloto no admin

Abra **AitoTokens → Uso e custos** para filtrar por origem, provedor e período. Compare o débito AitoTokens, o custo do provedor e a margem bruta em dólar e real. Consulte a requisição pelo ID do lançamento ao conferir uma reserva ou uma conciliação. A margem bruta considera a diferença entre o débito e o custo do provedor, antes de taxas, impostos e despesas operacionais.

## Recargas e suporte

A ferramenta de recarga gera um link da InfinitePay mediante pedido e confirmação do pacote. O pagamento é concluído pelo usuário. A carteira é atualizada após a confirmação da InfinitePay. Use a ferramenta de saldo quando houver um aviso de crédito insuficiente ou uma nova recarga.

Com a carteira zerada, consulte o saldo e gere o link pelo terminal usando a mesma variável local, a partir da pasta distribuída. Esses comandos acessam a carteira diretamente.

```powershell
node carteira.mjs saldo
node carteira.mjs recarregar 5
```

O atalho do app gráfico usa o Gerenciador de Credenciais do Windows. No modo CLI manual, a variável do exemplo é apagada quando a sessão termina. Se a credencial for exposta, regenere-a em **Meus dados**.
