[CmdletBinding()]
param([string]$OutputDirectory = (Split-Path -Parent $PSScriptRoot))

$ErrorActionPreference = 'Stop'
$compiler = @('Framework64', 'Framework') | ForEach-Object {
    Join-Path $env:WINDIR "Microsoft.NET\$_\v4.0.30319\csc.exe"
} | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (!$compiler) { throw 'Compilador C# do .NET Framework 4.x indisponível.' }

$pluginDirectory = Join-Path $OutputDirectory 'plugin'
New-Item -ItemType Directory -Path $OutputDirectory, $pluginDirectory -Force | Out-Null
$root = Split-Path -Parent $PSScriptRoot
$manifest = Join-Path $PSScriptRoot 'AitoCodexWindows.manifest'

function Build-AitoExecutable([string]$Source, [string]$Icon, [string]$Output, [string[]]$AdditionalReferences = @()) {
    $sourcePath = Join-Path $PSScriptRoot $Source
    $references = @('System.dll', 'System.Drawing.dll', 'System.Windows.Forms.dll') + $AdditionalReferences
    $arguments = @('/nologo', '/target:winexe', '/platform:anycpu', '/optimize+', '/codepage:65001',
        "/out:$Output", "/win32icon:$Icon", "/win32manifest:$manifest") + @($references | ForEach-Object { "/reference:$_" }) + @($sourcePath)
    & $compiler @arguments
    if ($LASTEXITCODE -ne 0) { throw "Falha ao compilar $Source." }
}

Build-AitoExecutable -Source 'AitoCodexKey.cs' -Icon (Join-Path $PSScriptRoot 'AitoCodexKey.ico') `
    -Output (Join-Path $pluginDirectory 'Configurar AitoCodex Key.exe') -AdditionalReferences @('System.Web.Extensions.dll')
Build-AitoExecutable -Source 'AitoWindowsLauncher.cs' -Icon (Join-Path $root 'AitoSoftwares.ico') `
    -Output (Join-Path $OutputDirectory 'Iniciar AitoIA.exe') `
    -AdditionalReferences @('System.IO.Compression.dll', 'System.IO.Compression.FileSystem.dll')
