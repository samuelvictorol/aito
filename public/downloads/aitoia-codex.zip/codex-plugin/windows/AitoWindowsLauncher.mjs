import { execFile } from 'node:child_process';
import { mkdir, mkdtemp, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { delimiter, dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { configureAitoProvider, restoreAitoProvider, windowsProfileHelp } from '../Configurar-AitoCodex.mjs';
import { checkPluginUpdate, downloadVerifiedUpdate, pluginVersion } from '../plugin/updates.mjs';
import { launcherName, launcherRegistration } from '../plugin/windows-launcher.mjs';

const execute = promisify(execFile);
const packageRoot = fileURLToPath(new URL('../', import.meta.url)).replace(/[\\/]$/, '');
const installer = join(packageRoot, launcherName);
const keyEditor = join(packageRoot, 'plugin', 'Configurar AitoCodex Key.exe');
const marketplaceName = 'aitosoftwares-pilot';
const pluginId = 'aitosoftwares@' + marketplaceName;

const cliAliases = new Map([
  ['-setuponly', '--setup-only'], ['-createshortcut', '--create-shortcut'], ['-shortcut', '--shortcut'],
  ['-useaitoprovider', '--use-aito-provider'], ['-updateonly', '--update'], ['-uninstall', '--uninstall'],
  ['-replacekey', '--configure-key'], ['-projectdirectory', '--project'],
]);

function parseOptions(args) {
  const result = { flags: new Set(), project: '' };
  for (let index = 0; index < args.length; index += 1) {
    const option = cliAliases.get(args[index].toLowerCase()) || args[index].toLowerCase();
    if (option === '--project' && args[index + 1]) result.project = resolve(args[++index]);
    else if (['--setup-only', '--create-shortcut', '--shortcut', '--update', '--uninstall', '--use-aito-provider', '--configure-key'].includes(option)) {
      result.flags.add(option);
    } else throw Error('Argumento desconhecido. Abra Iniciar AitoIA.exe pelo Explorador de Arquivos.');
  }
  return result;
}

const run = (command, args, timeout = 45000) => execute(command, args, {
  cwd: homedir(), encoding: 'utf8', windowsHide: true, timeout, maxBuffer: 256 * 1024,
});
const ui = (action, ...args) => run(installer, ['--aitowin-' + action, ...args], 0);

async function consent(message, title = 'AitoIA - Codex') {
  try { await ui('confirm', title, message); return true; }
  catch (error) { if (error.code === 2) return false; throw error; }
}

async function findCodex() {
  const candidates = [];
  let profileUnavailable = false;
  if (process.env.LOCALAPPDATA) {
    const bin = join(process.env.LOCALAPPDATA, 'OpenAI', 'Codex', 'bin');
    const directories = await readdir(bin, { withFileTypes: true }).catch(() => []);
    const versions = await Promise.all(directories.filter(entry => entry.isDirectory()).map(async entry => {
      const path = join(bin, entry.name, 'codex.exe');
      return { path, time: (await stat(path).catch(() => null))?.mtimeMs || 0 };
    }));
    candidates.push(join(bin, 'codex.exe'), ...versions.sort((a, b) => b.time - a.time).map(entry => entry.path),
      join(process.env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Links', 'codex.exe'));
  }
  const pathEntries = (process.env.PATH || '').split(delimiter).map(path => path.trim().replace(/^"|"$/g, '')).filter(Boolean);
  for (const path of pathEntries) candidates.push(join(path, 'codex.exe'), join(path, 'codex.cmd'));
  if (process.env.APPDATA) candidates.push(join(process.env.APPDATA, 'npm', 'codex.cmd'));
  if (process.env.ProgramFiles) candidates.push(join(process.env.ProgramFiles, 'nodejs', 'codex.cmd'));

  for (const candidate of new Set(candidates)) {
    const file = await stat(candidate).catch(() => null);
    if (!file?.isFile()) continue;
    const native = extname(candidate).toLowerCase() === '.exe';
    const command = native ? candidate : process.execPath;
    const prefix = native ? [] : [join(dirname(candidate), 'node_modules', '@openai', 'codex', 'bin', 'codex.js')];
    try {
      const version = await run(command, [...prefix, '--version'], 5000);
      if (!/^codex-cli\s/.test(version.stdout)) continue;
      const help = await run(command, [...prefix, 'app', '--help'], 5000);
      if (/^Usage: codex app\b/m.test(help.stdout)) return { command, prefix };
    } catch (error) {
      if (cannotFindProfile(error)) profileUnavailable = true;
    }
  }
  if (profileUnavailable) throw Error(windowsProfileHelp);
  throw Error('Instale ou atualize o aplicativo oficial do Codex em https://openai.com/codex/ e abra Iniciar AitoIA.exe novamente.');
}

function cannotFindProfile(error) {
  return /could not find home directory/i.test((error.stderr || '') + (error.stdout || ''));
}

async function invokeCodex(codex, ...args) {
  try { return (await run(codex.command, [...codex.prefix, ...args])).stdout; }
  catch (error) {
    if (cannotFindProfile(error)) throw Error(windowsProfileHelp);
    throw Error('O aplicativo Codex não concluiu a operação. Confira se está atualizado e tente novamente.');
  }
}

async function registerPlugin(codex) {
  const { marketplaces } = JSON.parse(await invokeCodex(codex, 'plugin', 'marketplace', 'list', '--json'));
  const existing = marketplaces.find(entry => entry.name === marketplaceName);
  const sameRoot = typeof existing?.root === 'string' && resolve(existing.root).toLowerCase() === packageRoot.toLowerCase();
  if (sameRoot) {
    const { installed } = JSON.parse(await invokeCodex(codex, 'plugin', 'list', '--json'));
    if (installed.some(entry => entry.pluginId === pluginId && entry.enabled && entry.version === pluginVersion)) return;
  }
  if (existing && !sameRoot) await invokeCodex(codex, 'plugin', 'marketplace', 'remove', marketplaceName);
  if (!sameRoot) {
    try { await invokeCodex(codex, 'plugin', 'marketplace', 'add', packageRoot); }
    catch (error) {
      if (existing?.root) await invokeCodex(codex, 'plugin', 'marketplace', 'add', existing.root).catch(() => {});
      throw error;
    }
  }
  const installed = JSON.parse(await invokeCodex(codex, 'plugin', 'add', '--json', pluginId));
  if (installed.version !== pluginVersion) throw Error('O Codex instalou outra versão do AitoIA. Extraia o ZIP oficial atualizado e tente novamente.');
}

async function createShortcuts() {
  await ui('create-shortcuts');
  const registration = launcherRegistration();
  if (!registration) return;
  await mkdir(dirname(registration), { recursive: true });
  await writeFile(registration, JSON.stringify({ launcher: installer }));
}

async function isCodexRunning() {
  try { await ui('codex-running'); return true; }
  catch (error) { if (error.code === 2) return false; throw error; }
}

async function uninstall(codex) {
  if (await isCodexRunning()) {
    throw Error('Salve o trabalho e escolha Sair no ícone do Codex perto do relógio do Windows. Depois, abra Desinstalar AitoIA.bat.');
  }
  if (!await consent('Remover o plugin, os atalhos e a AitoKey deste Windows e restaurar o provedor do Codex?', 'Desinstalar AitoIA')) return;
  await restoreAitoProvider(codex.command, codex.prefix);
  const { installed } = JSON.parse(await invokeCodex(codex, 'plugin', 'list', '--json'));
  if (installed.some(entry => entry.pluginId === pluginId)) await invokeCodex(codex, 'plugin', 'remove', pluginId);
  const { marketplaces } = JSON.parse(await invokeCodex(codex, 'plugin', 'marketplace', 'list', '--json'));
  if (marketplaces.some(entry => entry.name === marketplaceName)) await invokeCodex(codex, 'plugin', 'marketplace', 'remove', marketplaceName);
  await run(keyEditor, ['--remove']);
  await ui('remove-shortcuts');
  const registration = launcherRegistration();
  if (registration) await rm(registration, { force: true });
  await ui('notice', 'AitoIA desinstalado. Abra o Codex pelo aplicativo oficial.');
}

async function offerUpdate(showStatus) {
  let release;
  try { release = await checkPluginUpdate(); }
  catch {
    if (showStatus) await ui('notice', 'Não foi possível conferir a versão oficial. Tente novamente mais tarde.');
    return false;
  }
  if (!release.available) {
    if (showStatus) await ui('notice', `O AitoIA ${release.installedVersion} está atualizado.`);
    return false;
  }
  if (!await consent(`AitoIA ${release.latestVersion} está disponível. Baixar e verificar o ZIP oficial? Sua AitoKey continua salva no Windows.`, 'Atualizar AitoIA')) return false;
  if (!process.env.LOCALAPPDATA) throw Error('Não foi possível acessar a pasta de aplicativos desta conta do Windows.');
  const releases = join(process.env.LOCALAPPDATA, 'AitoSoftwares', 'Codex', 'Releases');
  await mkdir(releases, { recursive: true });
  const destination = await mkdtemp(join(releases, 'AitoIA-' + release.latestVersion + '-'));
  const archive = join(destination, 'aitoia-codex.zip');
  let prepared = false;
  try {
    await downloadVerifiedUpdate(release, archive);
    await ui('extract', archive, destination);
    const expanded = join(destination, 'codex-plugin');
    const metadata = JSON.parse(await readFile(join(expanded, 'plugin', '.codex-plugin', 'plugin.json'), 'utf8'));
    if (metadata.name !== 'aitosoftwares' || metadata.version !== release.latestVersion) throw Error('A versão do ZIP não corresponde ao manifesto oficial.');
    const nextInstaller = join(expanded, launcherName);
    for (const path of [nextInstaller, join(expanded, 'plugin', 'Configurar AitoCodex Key.exe'),
      join(expanded, 'windows', 'AitoWindowsLauncher.mjs')]) {
      if (!(await stat(path)).isFile()) throw Error('O ZIP oficial está incompleto.');
    }
    await rm(archive);
    await ui('notice', 'ZIP verificado. Encerre o Codex e abra Iniciar AitoIA.exe na pasta que será mostrada para instalar.');
    await ui('select-file', nextInstaller);
    prepared = true;
    return true;
  } catch {
    await ui('notice', 'Não foi possível verificar ou extrair o ZIP oficial. A versão atual continua instalada.');
    return false;
  } finally {
    if (!prepared && dirname(destination) === releases) await rm(destination, { recursive: true, force: true }).catch(() => {});
  }
}

async function ensureKey() {
  try { await run(keyEditor, ['--ensure'], 0); return true; }
  catch (error) {
    if (typeof error.code === 'number') return false; // The editor already handled recovery or cancellation.
    throw Error('Não foi possível abrir Configurar AitoCodex Key.exe. Extraia o ZIP inteiro e tente novamente.');
  }
}

async function start(args) {
  const { flags, project } = parseOptions(args);
  if (!(await stat(keyEditor).catch(() => null))?.isFile()) throw Error('Extraia o ZIP inteiro em uma pasta permanente antes de iniciar.');
  if (flags.has('--configure-key')) { await run(keyEditor, [], 0).catch(error => { if (typeof error.code !== 'number') throw error; }); return; }
  if (flags.has('--update')) { await offerUpdate(true); return; }

  const codex = await findCodex();
  if (flags.has('--uninstall')) { await uninstall(codex); return; }
  const setupOnly = flags.has('--setup-only');
  if (setupOnly) {
    await registerPlugin(codex);
    await createShortcuts();
    await ui('notice', 'Atalhos AitoIA - Codex e Configurar AitoCodex Key criados. Encerre o Codex pelo ícone perto do relógio e abra AitoIA - Codex.');
    return;
  }
  let switchProvider = flags.has('--use-aito-provider');
  const provider = { ...codex, auth: { command: keyEditor, args: ['--read'] } };
  const configured = await configureAitoProvider({ ...provider, switchProvider, checkOnly: true });

  if (await offerUpdate(false)) return;
  if (configured !== 'ready' && await isCodexRunning()) {
    throw Error('Salve o trabalho e escolha Sair no ícone do Codex perto do relógio do Windows. Depois, abra AitoIA - Codex.');
  }
  if (configured === 'provider-conflict') {
    switchProvider = await consent('O Codex tem outro provedor personalizado ativo. Usar AitoTokens como provedor padrão?');
    if (!switchProvider) return;
  }
  if (project && !(await stat(project).catch(() => null))?.isDirectory()) throw Error('Escolha uma pasta existente do Windows.');
  if (!flags.has('--shortcut') || flags.has('--create-shortcut')) await createShortcuts();
  if (!await ensureKey()) return;
  await registerPlugin(codex);
  if (configured !== 'ready') {
    const applied = await configureAitoProvider({ ...provider, switchProvider });
    if (!['ready', 'updated'].includes(applied)) throw Error('Não foi possível confirmar a configuração AitoTokens.');
  }
  await invokeCodex(codex, 'app', ...(project ? [project] : []));
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { await start(process.argv.slice(2)); }
  catch (error) {
    const message = error.name === 'Error' && !error.code ? error.message :
      'Não foi possível concluir a configuração. Confira a instalação do Codex e do Node.js.';
    await ui('error', message).catch(() => {});
    process.exitCode = 1;
  }
}
