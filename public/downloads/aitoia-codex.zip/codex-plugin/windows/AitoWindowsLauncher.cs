using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Win32;

namespace AitoSoftwares.Codex
{
    internal static class AitoWindowsLauncher
    {
        private const string Caption = "AitoIA - Codex";
        private const string KeyCaption = "Configurar AitoCodex Key";
        private const string Launcher = "Iniciar AitoIA.exe";
        private const string KeyEditor = "Configurar AitoCodex Key.exe";
        private static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;

        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                if (args.Length > 0 && args[0].StartsWith("--aitowin-", StringComparison.Ordinal)) return HandleWindowsAction(args);
                return StartSetup(args);
            }
            catch (Exception)
            {
                Show("Não foi possível concluir esta etapa no Windows. Abra Iniciar AitoIA.exe pelo Explorador, em uma pasta com o ZIP inteiro extraído.",
                    Caption, MessageBoxIcon.Error);
                return 1;
            }
        }

        private static int HandleWindowsAction(string[] args)
        {
            switch (args[0])
            {
                case "--aitowin-confirm":
                    if (args.Length != 3) return 1;
                    return MessageBox.Show(args[2], args[1], MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2) == DialogResult.Yes ? 0 : 2;
                case "--aitowin-notice":
                case "--aitowin-error":
                    if (args.Length != 2) return 1;
                    Show(args[1], Caption, args[0] == "--aitowin-error" ? MessageBoxIcon.Error : MessageBoxIcon.Information);
                    return 0;
                case "--aitowin-create-shortcuts":
                    if (args.Length != 1) return 1;
                    CreateShortcuts();
                    return 0;
                case "--aitowin-remove-shortcuts":
                    if (args.Length != 1) return 1;
                    RemoveShortcuts();
                    return 0;
                case "--aitowin-codex-running":
                    return args.Length == 1 ? (IsCodexRunning() ? 0 : 2) : 1;
                case "--aitowin-extract":
                    if (args.Length != 3) return 1;
                    ExpandPackage(args[1], args[2]);
                    return 0;
                case "--aitowin-select-file":
                    if (args.Length != 2 || !File.Exists(args[1])) return 1;
                    string explorer = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe");
                    using (Process.Start(new ProcessStartInfo(explorer, "/select," + Quote(args[1])))) { }
                    return 0;
                default:
                    return 1;
            }
        }

        private static int StartSetup(string[] args)
        {
            string script = Path.Combine(Root, "windows", "AitoWindowsLauncher.mjs");
            if (!File.Exists(script) || !File.Exists(Path.Combine(Root, "plugin", KeyEditor)))
            {
                Show("Extraia todos os arquivos do ZIP oficial para uma pasta e abra Iniciar AitoIA.exe nessa pasta.", Caption, MessageBoxIcon.Warning);
                return 1;
            }
            string node = FindNode();
            if (node == null)
            {
                if (MessageBox.Show("Instale o Node.js 20 ou superior e abra Iniciar AitoIA.exe novamente. Abrir a página oficial do Node.js?",
                    Caption, MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    using (Process.Start(new ProcessStartInfo("https://nodejs.org/pt-br/download") { UseShellExecute = true })) { }
                }
                return 1;
            }
            string arguments = Quote(script);
            foreach (string argument in args) arguments += " " + Quote(argument);
            var start = HiddenProcess(node, arguments);
            start.WorkingDirectory = Root;
            start.EnvironmentVariables.Remove("AITO_CODEX_API_KEY");
            start.EnvironmentVariables["PATH"] = Path.GetDirectoryName(node) + Path.PathSeparator + (start.EnvironmentVariables["PATH"] ?? "");
            using (Process process = Process.Start(start))
            {
                process.WaitForExit();
                return process.ExitCode;
            }
        }

        private static string FindNode()
        {
            string[] folders = {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "nodejs"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "nodejs"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "nodejs"),
            };
            foreach (string folder in folders)
            {
                string candidate = Path.Combine(folder, "node.exe");
                if (IsSupportedNode(candidate)) return candidate;
            }
            foreach (RegistryKey hive in new[] { Registry.CurrentUser, Registry.LocalMachine })
            {
                using (RegistryKey key = hive.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\App Paths\node.exe"))
                {
                    string candidate = key == null ? null : key.GetValue(null) as string;
                    if (candidate != null && IsSupportedNode(candidate.Trim('"'))) return candidate.Trim('"');
                }
            }
            foreach (string folder in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator))
            {
                string directory = folder.Trim().Trim('"');
                if (!Path.IsPathRooted(directory)) continue;
                string candidate = Path.Combine(directory, "node.exe");
                if (IsSupportedNode(candidate)) return candidate;
            }
            return null;
        }

        private static bool IsSupportedNode(string candidate)
        {
            if (!Path.IsPathRooted(candidate) || !File.Exists(candidate)) return false;
            try
            {
                var start = HiddenProcess(candidate, "--version");
                start.RedirectStandardOutput = true;
                using (Process process = Process.Start(start))
                {
                    if (!process.WaitForExit(3500)) { process.Kill(); return false; }
                    string version = process.StandardOutput.ReadToEnd().Trim();
                    Match match = Regex.Match(version, @"\Av(\d+)\.\d+\.\d+\z");
                    int major;
                    return process.ExitCode == 0 && match.Success && Int32.TryParse(match.Groups[1].Value, out major) && major >= 20;
                }
            }
            catch (Win32Exception) { return false; }
            catch (InvalidOperationException) { return false; }
        }

        private static ProcessStartInfo HiddenProcess(string executable, string arguments)
        {
            return new ProcessStartInfo(executable, arguments) { UseShellExecute = false, CreateNoWindow = true };
        }

        private static string Quote(string value)
        {
            var escaped = new StringBuilder("\"");
            int slashes = 0;
            foreach (char character in value)
            {
                if (character == '\\') { slashes++; continue; }
                escaped.Append('\\', character == '"' ? slashes * 2 + 1 : slashes).Append(character);
                slashes = 0;
            }
            return escaped.Append('\\', slashes * 2).Append('"').ToString();
        }

        private static void CreateShortcuts()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (!Directory.Exists(desktop)) throw new DirectoryNotFoundException();
            using (var shell = new ShellShortcuts())
            {
                shell.Save(Path.Combine(desktop, Caption + ".lnk"), Application.ExecutablePath,
                    "--shortcut", Root, "Abrir Codex com AitoTokens");
                shell.Save(Path.Combine(desktop, KeyCaption + ".lnk"), Path.Combine(Root, "plugin", KeyEditor),
                    "", Root, "Cadastrar ou trocar a AitoKey deste Windows");
            }
        }

        private static void RemoveShortcuts()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (!Directory.Exists(desktop)) return;
            using (var shell = new ShellShortcuts())
            {
                shell.Remove(Path.Combine(desktop, Caption + ".lnk"), Launcher, true);
                shell.Remove(Path.Combine(desktop, KeyCaption + ".lnk"), KeyEditor, false);
            }
        }

        private static bool IsCodexRunning()
        {
            foreach (string name in new[] { "Codex", "ChatGPT" })
            {
                bool found = false;
                foreach (Process process in Process.GetProcessesByName(name))
                {
                    using (process)
                    {
                        try
                        {
                            string path = process.MainModule.FileName;
                            // The app package keeps a process in the tray even after its window closes.
                            if (Regex.IsMatch(path, @"\\OpenAI\.(?:Codex|ChatGPT)_[^\\]+\\", RegexOptions.IgnoreCase)) found = true;
                        }
                        catch (Win32Exception) { }
                        catch (InvalidOperationException) { }
                    }
                }
                if (found) return true;
            }
            return false;
        }

        private static void ExpandPackage(string archive, string destination)
        {
            string area = Path.GetFullPath(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AitoSoftwares", "Codex", "Releases")) + Path.DirectorySeparatorChar;
            string root = Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string prefix = root + Path.DirectorySeparatorChar;
            if (!prefix.StartsWith(area, StringComparison.OrdinalIgnoreCase) || prefix.Length <= area.Length ||
                !String.Equals(Path.GetFullPath(archive), Path.Combine(root, "aitoia-codex.zip"), StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException();

            using (ZipArchive package = ZipFile.OpenRead(archive))
            {
                if (package.Entries.Count > 2000) throw new InvalidDataException();
                long size = 0;
                foreach (ZipArchiveEntry entry in package.Entries)
                {
                    size += entry.Length;
                    string name = entry.FullName.Replace('\\', '/');
                    if (size > 32 * 1024 * 1024 || !name.StartsWith("codex-plugin/", StringComparison.Ordinal) || name.Contains(":"))
                        throw new InvalidDataException();
                    string output = Path.GetFullPath(Path.Combine(root, name));
                    if (!output.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException();
                    if (name.EndsWith("/", StringComparison.Ordinal)) { Directory.CreateDirectory(output); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(output));
                    entry.ExtractToFile(output, false);
                }
            }
        }

        private static void Show(string message, string title, MessageBoxIcon icon)
        {
            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
        }

        private sealed class ShellShortcuts : IDisposable
        {
            private readonly object shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell", true));

            internal void Save(string path, string executable, string arguments, string directory, string description)
            {
                object link = Invoke(shell, "CreateShortcut", BindingFlags.InvokeMethod, path);
                try
                {
                    Invoke(link, "TargetPath", BindingFlags.SetProperty, executable);
                    Invoke(link, "Arguments", BindingFlags.SetProperty, arguments);
                    Invoke(link, "WorkingDirectory", BindingFlags.SetProperty, directory);
                    Invoke(link, "Description", BindingFlags.SetProperty, description);
                    Invoke(link, "IconLocation", BindingFlags.SetProperty, executable + ",0");
                    Invoke(link, "Save", BindingFlags.InvokeMethod);
                }
                finally { Marshal.FinalReleaseComObject(link); }
            }

            internal void Remove(string path, string executable, bool acceptLegacy)
            {
                if (!File.Exists(path)) return;
                object link = Invoke(shell, "CreateShortcut", BindingFlags.InvokeMethod, path);
                try
                {
                    string target = Path.GetFileName((string)Invoke(link, "TargetPath", BindingFlags.GetProperty));
                    string arguments = (string)Invoke(link, "Arguments", BindingFlags.GetProperty);
                    bool native = String.Equals(target, executable, StringComparison.OrdinalIgnoreCase);
                    bool legacy = acceptLegacy && String.Equals(target, "powershell.exe", StringComparison.OrdinalIgnoreCase) &&
                        Regex.IsMatch(arguments ?? "", "-File\\s+\"[^\"\\r\\n]+[\\\\/]Iniciar-AitoIA\\.ps1\"\\s+-Shortcut\\s*$", RegexOptions.IgnoreCase);
                    if (native || legacy) File.Delete(path);
                }
                finally { Marshal.FinalReleaseComObject(link); }
            }

            public void Dispose() { Marshal.FinalReleaseComObject(shell); }

            private static object Invoke(object target, string member, BindingFlags action, params object[] arguments)
            {
                return target.GetType().InvokeMember(member, action, null, target, arguments);
            }
        }
    }
}
