using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace AitoSoftwares.Codex
{
    internal static class AitoCodexKey
    {
        private static readonly Regex KeyPattern = new Regex(@"\Aaito_(?:usr|prj)_[A-Za-z0-9_-]{48}\z");

        [STAThread]
        private static int Main(string[] args)
        {
            if (args.Length > 1) return 1;
            string mode = args.Length == 0 ? "" : args[0];
            bool interactive = mode == "" || mode == "--ensure";
            try
            {
                switch (mode)
                {
                    case "--read":
                        if (!WindowsVault.HasOutputPipe) return 1;
                        string key = WindowsVault.Read();
                        if (!IsKey(key)) return 3;
                        Console.WriteLine(key);
                        return 0;
                    case "--has-key": return IsKey(WindowsVault.Read()) ? 0 : 3;
                    case "--remove": WindowsVault.Remove(); return 0;
                    case "--ensure":
                    case "": return RunDialog(mode == "--ensure");
                    default: return 1;
                }
            }
            catch (Exception)
            {
                if (interactive) MessageBox.Show("O Gerenciador de Credenciais do Windows não respondeu. Tente novamente com sua conta do Windows.",
                    KeyDialog.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }

        internal static bool IsKey(string value)
        {
            return value != null && KeyPattern.IsMatch(value);
        }

        private static int RunDialog(bool ensure)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            string explanation = null;
            if (ensure)
            {
                string stored = WindowsVault.Read();
                if (IsKey(stored))
                {
                    KeyStatus state = KeyValidation.Check(stored);
                    if (state == KeyStatus.Active || state == KeyStatus.Unavailable) return 0;
                    if (state == KeyStatus.AccessDenied)
                    {
                        MessageBox.Show(KeyValidation.Explain(state), KeyDialog.Caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return 1;
                    }
                    explanation = KeyValidation.Explain(state);
                }
                else if (stored != null)
                {
                    explanation = "A AitoKey salva tem um formato inválido. Cole a chave atual para continuar.";
                }
            }
            using (var dialog = new KeyDialog(explanation, ensure))
                return dialog.ShowDialog() == DialogResult.OK ? 0 : 2;
        }
    }

    internal enum KeyStatus { Active, Rejected, WalletUnavailable, AccessDenied, Unavailable }

    internal static class KeyValidation
    {
        private const string Endpoint = "https://api.aitosoftwares.com/aito-tokens/codex/v1/credentials/check";

        internal static KeyStatus Check(string key)
        {
            try
            {
                // TLS 1.2 on systems where .NET has not enabled it by default.
                ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072;
                var request = (HttpWebRequest)WebRequest.Create(Endpoint);
                request.Method = "POST";
                request.ContentLength = 0;
                request.AllowAutoRedirect = false;
                request.Timeout = 8000;
                request.ReadWriteTimeout = 8000;
                request.Accept = "application/json";
                request.Headers[HttpRequestHeader.Authorization] = "Bearer " + key;
                HttpWebResponse response;
                try { response = (HttpWebResponse)request.GetResponse(); }
                catch (WebException failure) { response = failure.Response as HttpWebResponse; }
                if (response == null) return KeyStatus.Unavailable;
                using (response)
                {
                    if (response.StatusCode == HttpStatusCode.NoContent) return KeyStatus.Active;
                    if (response.StatusCode != HttpStatusCode.Unauthorized && response.StatusCode != HttpStatusCode.Forbidden)
                        return KeyStatus.Unavailable;
                    using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                    {
                        var buffer = new char[4096];
                        int length = reader.ReadBlock(buffer, 0, buffer.Length);
                        if (length == buffer.Length) return KeyStatus.Unavailable;
                        var parser = new JavaScriptSerializer { MaxJsonLength = buffer.Length, RecursionLimit = 8 };
                        var error = parser.Deserialize<ErrorEnvelope>(new string(buffer, 0, length));
                        switch (error == null || error.error == null ? null : error.error.code)
                        {
                            case "invalid_api_key": return KeyStatus.Rejected;
                            case "wallet_unavailable": return KeyStatus.WalletUnavailable;
                            case "codex_access_denied": return KeyStatus.AccessDenied;
                            default: return KeyStatus.Unavailable;
                        }
                    }
                }
            }
            catch (Exception) { return KeyStatus.Unavailable; }
        }

        internal static string Explain(KeyStatus value)
        {
            switch (value)
            {
                case KeyStatus.Rejected: return "A AitoKey expirou ou foi revogada. Copie a chave atual em Meus dados.";
                case KeyStatus.WalletUnavailable: return "Carteira indisponível. Confira a licença ou selecione uma carteira ativa em Meus dados.";
                case KeyStatus.AccessDenied: return "O acesso ao Codex está bloqueado para esta carteira. Confira Meus dados.";
                default: return "A verificação está temporariamente indisponível. A credencial existente continua salva.";
            }
        }

        public sealed class ErrorEnvelope { public ApiError error { get; set; } }
        public sealed class ApiError { public string code { get; set; } }
    }

    internal sealed class KeyDialog : Form
    {
        internal const string Caption = "Configurar AitoCodex Key";
        private const string Profile = "https://aitosoftwares.com/app?tab=profile";
        private readonly Color accent = Color.FromArgb(94, 234, 212);
        private readonly Color muted = Color.FromArgb(178, 211, 205);
        private readonly TextBox entry;
        private readonly Button save;
        private readonly Label status;
        private readonly bool ensure;

        internal KeyDialog(string explanation, bool ensure)
        {
            this.ensure = ensure;
            Text = Caption;
            Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96, 96);
            ClientSize = new Size(498, 263);
            BackColor = Color.FromArgb(9, 37, 35);
            ForeColor = Color.FromArgb(220, 249, 244);
            Font = new Font("Segoe UI", 10);

            var title = new Label { Text = "Conecte seus AitoTokens", Font = new Font(Font.FontFamily, 15, FontStyle.Bold),
                Bounds = new Rectangle(22, 17, 454, 30), ForeColor = accent };
            var help = new Label { Text = "Copie a AitoKey em Meus dados. O Windows guarda a chave para suas próximas conversas.",
                Bounds = new Rectangle(22, 53, 454, 52), ForeColor = muted };
            var label = new Label { Text = "Aito&Key", Bounds = new Rectangle(22, 105, 454, 20), TabIndex = 0 };
            entry = new TextBox { UseSystemPasswordChar = true, MaxLength = 160, AccessibleName = "AitoKey",
                Location = new Point(22, 129), Width = 454, TabIndex = 1, ShortcutsEnabled = true,
                BackColor = Color.FromArgb(14, 54, 51), ForeColor = Color.White };
            status = new Label { Bounds = new Rectangle(22, 161, 454, 48), AccessibleName = "Estado da verificação",
                ForeColor = muted, Text = explanation ?? "" };
            var profile = NewButton("Abrir Meus dados", new Rectangle(22, 215, 144, 32), 2);
            profile.Click += delegate
            {
                try { Process.Start(new ProcessStartInfo(Profile) { UseShellExecute = true }); }
                catch (Exception) { SetStatus("Abra aitosoftwares.com/app e selecione Meus dados.", true); }
            };
            var cancel = NewButton("Cancelar", new Rectangle(272, 215, 94, 32), 3);
            cancel.DialogResult = DialogResult.Cancel;
            save = NewButton("Salvar chave", new Rectangle(373, 215, 103, 32), 4);
            save.BackColor = accent;
            save.ForeColor = BackColor;
            save.Click += SaveKey;

            Controls.AddRange(new Control[] { title, help, label, entry, status, profile, cancel, save });
            AcceptButton = save;
            CancelButton = cancel;
            ActiveControl = entry;
        }

        private Button NewButton(string text, Rectangle bounds, int tabIndex)
        {
            var button = new Button { Text = text, Bounds = bounds, TabIndex = tabIndex, FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(18, 57, 53), ForeColor = ForeColor };
            button.FlatAppearance.BorderColor = Color.FromArgb(63, 121, 111);
            return button;
        }

        private void SetStatus(string message, bool warning)
        {
            status.Text = message;
            status.ForeColor = warning ? Color.FromArgb(253, 211, 162) : muted;
        }

        private async void SaveKey(object sender, EventArgs args)
        {
            string key = entry.Text.Trim();
            if (!AitoCodexKey.IsKey(key))
            {
                SetStatus("Formato inválido. Copie a AitoKey completa em Meus dados.", true);
                entry.Focus();
                return;
            }
            save.Enabled = false;
            entry.ReadOnly = true;
            SetStatus("Verificando AitoKey…", false);
            try
            {
                KeyStatus result = await Task.Run(() => KeyValidation.Check(key));
                if (IsDisposed || Disposing || DialogResult == DialogResult.Cancel) return;
                if (result != KeyStatus.Active)
                {
                    SetStatus(KeyValidation.Explain(result), true);
                    return;
                }
                WindowsVault.Write(key);
                entry.Clear();
                if (!ensure) MessageBox.Show(this, "AitoKey salva. Se o Codex estiver aberto, salve seu trabalho e reabra pelo atalho AitoIA - Codex.",
                    Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception)
            {
                if (!IsDisposed && !Disposing) SetStatus("O Windows não conseguiu gravar a AitoKey. A credencial existente continua salva.", true);
            }
            finally
            {
                key = null;
                if (!IsDisposed && !Disposing)
                {
                    entry.ReadOnly = false;
                    save.Enabled = true;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && entry != null) entry.Clear();
            base.Dispose(disposing);
        }
    }

    internal static class WindowsVault
    {
        private const string Target = "AitoSoftwares.Codex.AitoTokens.v1";
        private const uint Generic = 1;
        private const uint LocalMachine = 2;
        private const int NotFound = 1168;
        private const int KeyBytes = 57 * sizeof(char);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct Credential
        {
            internal uint Flags;
            internal uint Type;
            internal string TargetName;
            internal string Comment;
            internal System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            internal uint BlobSize;
            internal IntPtr Blob;
            internal uint Persist;
            internal uint AttributeCount;
            internal IntPtr Attributes;
            internal string TargetAlias;
            internal string UserName;
        }

        [DllImport("Advapi32.dll", EntryPoint = "CredReadW", ExactSpelling = true, CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);

        [DllImport("Advapi32.dll", EntryPoint = "CredWriteW", ExactSpelling = true, CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredWrite(ref Credential credential, uint flags);

        [DllImport("Advapi32.dll", EntryPoint = "CredDeleteW", ExactSpelling = true, CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredDelete(string target, uint type, uint flags);

        [DllImport("Advapi32.dll")]
        private static extern void CredFree(IntPtr credential);

        [DllImport("Kernel32.dll")]
        private static extern IntPtr GetStdHandle(int handle);

        [DllImport("Kernel32.dll")]
        private static extern uint GetFileType(IntPtr handle);

        internal static bool HasOutputPipe { get { return GetFileType(GetStdHandle(-11)) == 3; } }

        internal static string Read()
        {
            IntPtr pointer;
            if (!CredRead(Target, Generic, 0, out pointer))
            {
                int error = Marshal.GetLastWin32Error();
                if (error == NotFound) return null;
                throw new Win32Exception(error);
            }
            try
            {
                var credential = (Credential)Marshal.PtrToStructure(pointer, typeof(Credential));
                if (credential.Blob == IntPtr.Zero || credential.BlobSize != KeyBytes) return String.Empty;
                try { return Marshal.PtrToStringUni(credential.Blob, KeyBytes / sizeof(char)); }
                finally { for (int i = 0; i < KeyBytes; i++) Marshal.WriteByte(credential.Blob, i, 0); }
            }
            finally { CredFree(pointer); }
        }

        internal static void Write(string key)
        {
            if (!AitoCodexKey.IsKey(key)) throw new ArgumentException("Invalid key format.");
            var bytes = Marshal.StringToCoTaskMemUni(key);
            try
            {
                var credential = new Credential { Type = Generic, TargetName = Target, Comment = "AitoTokens for Codex", BlobSize = KeyBytes,
                    Blob = bytes, Persist = LocalMachine, UserName = "AitoSoftwares" };
                if (!CredWrite(ref credential, 0)) throw new Win32Exception(Marshal.GetLastWin32Error());
            }
            finally { Marshal.ZeroFreeCoTaskMemUnicode(bytes); }
        }

        internal static void Remove()
        {
            if (CredDelete(Target, Generic, 0)) return;
            int error = Marshal.GetLastWin32Error();
            if (error != NotFound) throw new Win32Exception(error);
        }
    }
}
