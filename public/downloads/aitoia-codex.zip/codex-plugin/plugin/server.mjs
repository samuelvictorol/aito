import { randomUUID } from 'node:crypto';
import { mkdir, open, unlink } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { createInterface } from 'node:readline';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { checkPluginUpdate, pluginVersion } from './updates.mjs';
import { resolveNativeLauncher } from './windows-launcher.mjs';

const apiBase = 'https://api.aitosoftwares.com/aito-tokens';
const rechargeUrl = 'https://aitosoftwares.com/aitotokens#pacotes';
const keyPattern = /^aito_(?:usr|prj)_[A-Za-z0-9_-]{48}$/;
const runFile = promisify(execFile);
const keyEditor = fileURLToPath(new URL('./Configurar AitoCodex Key.exe', import.meta.url));
export const rechargePackageCents = Object.freeze([500, 1000, 1500, 2500, 5000, 10000]);
const supportedProtocols = ['2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'];
const orderPattern = /^aito-tokens-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const readOnly = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true };
const imageFields = {
  prompt: { type: 'string', minLength: 1, maxLength: 16000 },
  model: { type: 'string', description: 'Modelo de imagem da Aito. Padrão: gpt-image-2.' },
  size: { type: 'string' },
  quality: { type: 'string', enum: ['low', 'medium', 'high', 'auto'] },
};
const spendingInstructions = 'Execute as tarefas solicitadas diretamente com AitoTokens. A geração de imagem usa aitotokens_generate_image com a AitoKey. A API verifica o saldo e cobra pelo uso. Entregue a imagem pelo caminho local retornado pela ferramenta, sem recriar ou salvar a imagem novamente. Se uma geração falhar, não repita automaticamente.';
const tools = [
  {
    name: 'aitotokens_generate_image',
    description: 'Gera uma imagem solicitada pelo usuário e cobra o consumo da carteira AitoTokens com a AitoKey.',
    inputSchema: { type: 'object', properties: imageFields, required: ['prompt'], additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  },
  {
    name: 'aitotokens_help',
    description: 'Mostra o guia rápido do plugin AitoIA, com exemplos para modelo, saldo, consumo, recarga e atualizações.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: { ...readOnly, openWorldHint: false },
  },
  {
    name: 'aitotokens_check_update',
    description: 'Compara a versão instalada do plugin AitoIA com a versão oficial da AitoSoftwares. Apenas consulta.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_open_updater',
    title: 'Abrir atualizador do AitoIA',
    description: 'No Windows, abre a janela oficial de atualização após um pedido explícito do usuário. A janela pede confirmação antes de baixar o ZIP e deixa a instalação a cargo do usuário.',
    inputSchema: { type: 'object', properties: { confirmed: { const: true } }, required: ['confirmed'], additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  },
  {
    name: 'aitotokens_reconnect',
    title: 'Configurar AitoCodex Key',
    description: 'Abre a janela protegida para cadastrar uma nova AitoKey no Windows após um pedido explícito do usuário. A chave deve ser informada unicamente na janela local.',
    inputSchema: { type: 'object', properties: { confirmed: { const: true } }, required: ['confirmed'], additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  },
  {
    name: 'aitotokens_status',
    description: 'Consulta o saldo e o estado da AitoKey e lista os pacotes de recarga.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_usage',
    description: 'Consulta o consumo de AitoTokens do Codex nos últimos 30 dias.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_recharge_history',
    description: 'Consulta as recargas desta carteira, com paginação.',
    inputSchema: { type: 'object', properties: { offset: { type: 'integer', minimum: 0, maximum: 100000 } }, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_create_checkout',
    description: 'Gera um link de recarga da InfinitePay depois que o usuário confirma o pacote. O usuário abre e paga o link.',
    inputSchema: { type: 'object', required: ['usdCents', 'confirmed'], properties: {
      usdCents: { type: 'integer', enum: rechargePackageCents },
      confirmed: { type: 'boolean', const: true, description: 'O usuário confirmou expressamente a criação do link neste chat.' },
    }, additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  },
  {
    name: 'aitotokens_recharge_status',
    description: 'Consulta a confirmação da InfinitePay para um pedido desta carteira.',
    inputSchema: { type: 'object', required: ['orderNsu'], properties: {
      orderNsu: { type: 'string', maxLength: 48, pattern: orderPattern.source },
    }, additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  },
];

const asObject = value => value && typeof value === 'object' && !Array.isArray(value);
const finite = value => Number.isFinite(value) && value >= 0 ? value : undefined;
const timestamp = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(value) ? value : undefined;
const currency = code => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: code, maximumFractionDigits: 4 });
const usd = currency('USD');
const brl = currency('BRL');

function checkoutUrl(value) {
  if (typeof value !== 'string' || value.length > 2048) return undefined;
  try {
    const url = new URL(value);
    if (url.protocol === 'https:' && !url.username && !url.password && !url.port &&
        /(^|\.)infinitepay\.(io|com\.br)$/.test(url.hostname)) return url.href;
  } catch { /* The checkout is unavailable. */ }
}

function chargeStatus(value) {
  return ['pending', 'paid', 'expired', 'failed'].includes(value) ? value : 'unavailable';
}

function rechargeDto(row) {
  if (!asObject(row) || typeof row.orderNsu !== 'string' || !orderPattern.test(row.orderNsu)) return undefined;
  return { orderNsu: row.orderNsu, usdCents: finite(row.usdCents), brlCents: finite(row.brlCents),
    status: chargeStatus(row.status), createdAt: timestamp(row.createdAt), paidAt: timestamp(row.paidAt) };
}

function toolResult(data, message) {
  return { content: [{ type: 'text', text: message || JSON.stringify(data) }], structuredContent: data };
}

function errorResult(message) {
  return { isError: true, content: [{ type: 'text', text: message }] };
}

function requestError(status, code) {
  if (code === 'AITO_IMAGE_UNDELIVERED') return Error('O provedor não devolveu uma imagem válida. A reserva foi liberada.');
  if (code === 'endpoint_unavailable') return Error('O recurso ainda não está habilitado para o piloto.');
  if (code === 'wallet_unavailable') return Error('Carteira indisponível. Confira a licença ou selecione uma carteira ativa em Meus dados na AitoSoftwares.');
  if (code === 'invalid_api_key' || (status === 401 && !code)) {
    return Error('AitoKey inválida, expirada ou revogada. Copie a chave atual em Meus dados e abra Configurar AitoCodex Key na Área de Trabalho.');
  }
  if (status === 401 || status === 403) return Error('Esta conta ou carteira está sem acesso ao Codex. Confira Meus dados na AitoSoftwares.');
  if (status === 402) return Error(`Saldo AitoTokens insuficiente. Recarregue a carteira em ${rechargeUrl}`);
  if (status === 404) return Error('O recurso solicitado está indisponível para esta carteira.');
  if (status === 409) return Error('A operação aguarda confirmação ou conciliação. Consulte o estado antes de fazer outro pedido.');
  if (status === 422) return Error('Os dados enviados são inválidos ou a cotação expirou.');
  if (status === 429) return Error('Aguarde antes de fazer uma nova consulta à AitoSoftwares.');
  if (status === 503) return Error('O serviço de AitoTokens está temporariamente indisponível.');
  return Error('A AitoSoftwares não conseguiu concluir a solicitação.');
}

async function localAitoKey() {
  if (process.platform !== 'win32') return process.env.AITO_CODEX_API_KEY;
  try {
    const { stdout } = await runFile(keyEditor, ['--read'], {
      windowsHide: true, timeout: 10000, maxBuffer: 4096, encoding: 'utf8', env: helperEnvironment(),
    });
    const key = stdout.trim();
    if (keyPattern.test(key)) return key;
  } catch { /* Never surface subprocess output or credential errors in a tool response. */ }
}

function helperEnvironment() {
  return Object.fromEntries(Object.entries(process.env)
    .filter(([name]) => name.toLowerCase() !== 'aito_codex_api_key'));
}

async function openWindowsHelper(helper, args = []) {
  if (!helper) throw Error('Assistente nativo indisponível.');
  const child = spawn(helper, args, { stdio: 'ignore', windowsHide: true, detached: true, env: helperEnvironment() });
  await new Promise((resolve, reject) => {
    child.once('spawn', resolve);
    child.once('error', reject);
  });
  child.unref();
  return true;
}

const openWindowsUpdater = async () => process.platform === 'win32' && openWindowsHelper(await resolveNativeLauncher(), ['--update']);
async function openWindowsKeyDialog() {
  if (process.platform !== 'win32') return false;
  try { return await openWindowsHelper(keyEditor); }
  catch { return openWindowsHelper(await resolveNativeLauncher(), ['--configure-key']); }
}

export function createDispatcher({ apiKey, resolveKey = localAitoKey, fetcher = globalThis.fetch,
  openUpdater = openWindowsUpdater, openKeyDialog = openWindowsKeyDialog,
  imageDirectory = join(homedir(), 'AitoIA', 'Imagens') } = {}) {
  async function post(path, body = {}, walletRoute = false, timeoutMs = 18000) {
    const key = apiKey === undefined ? await resolveKey() : apiKey;
    if (typeof key !== 'string' || !keyPattern.test(key) || key !== key.trim()) {
      throw Error('AitoKey indisponível. No Windows, abra Configurar AitoCodex Key na Área de Trabalho. Em outras plataformas, siga o guia do plugin.');
    }
    if (walletRoute) path = (key.startsWith('aito_usr_') ? '/codex/v1/account/' : '/runtime/') + path;
    let response;
    try {
      response = await fetcher(apiBase + path, {
        method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        body: JSON.stringify(body), redirect: 'error', signal: AbortSignal.timeout(timeoutMs),
      });
    } catch { throw requestError(503); }
    const result = await response.json().catch(() => null);
    if (!response.ok) throw requestError(response.status, result?.error?.code);
    if (!asObject(result?.data)) throw requestError();
    return result.data;
  }
  const postWallet = (resource, body) => post(resource, body, true);

  async function toolCall(name, args) {
    const tool = tools.find(item => item.name === name);
    if (!tool) return errorResult('Ferramenta AitoTokens desconhecida.');
    if (!asObject(args) || Object.keys(args).some(key => !Object.hasOwn(tool.inputSchema.properties, key))) {
      return errorResult('Parâmetros inválidos.');
    }
    if (name === 'aitotokens_generate_image') {
      const requestId = randomUUID();
      const filePath = join(imageDirectory, `aito-${requestId}.png`);
      let file;
      try {
        await mkdir(imageDirectory, { recursive: true, mode: 0o700 });
        file = await open(filePath, 'wx', 0o600);
      } catch {
        return errorResult('Não foi possível preparar a pasta de imagens. Nenhuma geração foi solicitada.');
      }

      let saved = false;
      let base64;
      let data;
      try {
        data = await post('/codex/v1/images/generate-direct', { ...args, requestId }, false, 210000);
        base64 = data.data?.[0]?.b64_json;
        if (typeof base64 !== 'string' || !base64.startsWith('iVBORw0KGgo')) {
          return errorResult(`O provedor não devolveu uma imagem PNG. Não repita a geração automaticamente. Pedido: ${requestId}.`);
        }
        await file.writeFile(Buffer.from(base64, 'base64'));
        await file.close();
        saved = true;
        const path = filePath.replaceAll('\\', '/');
        return toolResult({ ...data.aito, path, requestId },
          `Imagem salva em ${path}. Mostre-a ao usuário com ![Imagem gerada](<${path}>).`);
      } catch (error) {
        if (base64?.startsWith('iVBORw0KGgo')) {
          const result = toolResult({ ...data.aito, requestId },
            'Imagem gerada e anexada aqui. A gravação local falhou. Use a imagem anexada e não gere outra automaticamente.');
          result.content.push({ type: 'image', data: base64, mimeType: 'image/png' });
          return result;
        }
        return errorResult(`${error.message} Não repita a geração automaticamente. Pedido: ${requestId}.`);
      } finally {
        if (!saved) {
          await file.close().catch(() => {});
          await unlink(filePath).catch(() => {});
        }
      }
    }
    if (name === 'aitotokens_help') {
      return toolResult({ plugin: 'AitoIA', version: pluginVersion, mention: '@AitoIA', skill: '$aito-tokens' }, [
        '## AitoIA no Codex',
        'No seletor de contexto, procure **AitoIA**. Você também pode selecionar a skill **$aito-tokens**.',
        '',
        '| Quero… | Como fazer |',
        '| --- | --- |',
        '| Escolher um modelo | Abra o seletor de modelo e escolha entre as opções do provedor AitoTokens. |',
        '| Saber meu saldo | **Consulte meu saldo de AitoTokens.** |',
        '| Conferir gastos | **Mostre meu consumo recente de AitoTokens.** |',
        `| Recarregar | [Abra os pacotes no site](${rechargeUrl}) ou peça **Mostre os pacotes de recarga de AitoTokens.** |`,
        '| Cadastrar outra chave | **Abra Configurar AitoCodex Key.** |',
        '| Atualizar o plugin | **Verifique se há uma atualização do AitoIA.** |',
        '| Abrir o instalador de atualização | **Abra o atualizador do AitoIA.** |',
        '',
        'O plugin consulta sua carteira. O consumo das respostas do Codex depende de iniciar a conversa com o provedor **AitoTokens**.',
      ].join('\n'));
    }
    if (name === 'aitotokens_check_update') {
      let release;
      try { release = await checkPluginUpdate({ fetcher }); }
      catch { return errorResult('Não foi possível conferir a versão oficial do AitoIA agora. Tente novamente mais tarde.'); }
      const { installedVersion, available, latestVersion } = release;
      return toolResult(
        { installedVersion, available, latestVersion, ...(available ? { downloadUrl: release.downloadUrl } : {}) },
        available
          ? `AitoIA ${latestVersion} disponível. No Windows, peça **Abra o atualizador do AitoIA** e confirme o download na janela. Se estiver em outra plataforma, baixe o [ZIP oficial](${release.downloadUrl}) e siga o guia.`
          : `O AitoIA ${installedVersion} está atualizado.`,
      );
    }
    if (name === 'aitotokens_open_updater') {
      if (args.confirmed !== true) return errorResult('Peça ao usuário para confirmar a abertura do atualizador.');
      try {
        const opened = await openUpdater();
        return opened
          ? toolResult({ opened }, 'Confira a janela **Atualizar AitoIA** do Windows. Ela verifica a versão e pede confirmação antes de baixar o pacote.')
          : toolResult({ opened }, 'Em outras plataformas, baixe o [ZIP oficial](https://aitosoftwares.com/aitoia-codex) e siga o guia.');
      } catch { return errorResult('Não foi possível abrir o atualizador. Abra o atalho AitoIA - Codex ou use o ZIP oficial.'); }
    }
    if (name === 'aitotokens_reconnect') {
      if (args.confirmed !== true) return errorResult('Peça ao usuário para confirmar que quer abrir a janela de troca da AitoKey.');
      try {
        const opened = await openKeyDialog();
        return opened
          ? toolResult({ opened }, 'Informe a nova AitoKey na janela protegida **Configurar AitoCodex Key**. Reabra o Codex pelo atalho se a sessão ainda usar a chave anterior.')
          : toolResult({ opened }, 'Em outras plataformas, substitua a chave no ambiente local e reinicie o Codex seguindo o guia do plugin.');
      } catch { return errorResult('Não foi possível abrir a janela pelo Codex. Abra Configurar AitoCodex Key na Área de Trabalho.'); }
    }
    if (name === 'aitotokens_status') {
      const result = await postWallet('status');
      const balanceUsd = finite(result.balanceUsd);
      const balanceBrl = finite(result.balanceBrl);
      const data = { credential: 'active', balanceUsd, balanceBrl, approximateTokens: finite(result.approximateTokens),
        canUse: result.canUse === true, lowBalance: result.lowBalance === true, checkoutConfigured: result.checkoutConfigured === true,
        plans: Array.isArray(result.plans) ? result.plans.filter(plan => rechargePackageCents.includes(plan?.usdCents)).map(plan => ({
          usdCents: plan.usdCents, brlCents: finite(plan.brlCents), approximateTokens: finite(plan.approximateTokens),
        })) : [] };
      const warning = balanceUsd === 0 ? 'Saldo zerado.' : data.lowBalance ? 'Saldo próximo de acabar.' : '';
      return toolResult(data, ['AitoKey ativa.', balanceUsd !== undefined && balanceBrl !== undefined
        ? `Saldo de ${usd.format(balanceUsd)} (${brl.format(balanceBrl)}).` : '',
        data.approximateTokens !== undefined ? `Estimativa de ${data.approximateTokens.toLocaleString('pt-BR')} tokens.` : '',
        warning && `${warning} [Ver pacotes de recarga](${rechargeUrl})`].filter(Boolean).join(' '));
    }
    if (name === 'aitotokens_usage') {
      const result = await post('/codex/v1/account/usage');
      const data = { periodDays: finite(result.periodDays), requests: finite(result.requests),
        inputTokens: finite(result.inputTokens), outputTokens: finite(result.outputTokens), cachedTokens: finite(result.cachedTokens),
        billedUsdCents: finite(result.billedUsdCents), billedBrlCents: finite(result.billedBrlCents),
        bySource: Array.isArray(result.bySource) ? result.bySource.filter(row => /^codex_[a-z]+$/.test(row?.source)).map(row => ({
          source: row.source, requests: finite(row.requests), billedUsdCents: finite(row.billedUsdCents), billedBrlCents: finite(row.billedBrlCents),
        })) : [] };
      return toolResult(data);
    }
    if (name === 'aitotokens_recharge_history') {
      const { offset = 0 } = args;
      if (!Number.isSafeInteger(offset) || offset < 0 || offset > 100000) return errorResult('Informe um deslocamento entre 0 e 100000.');
      const result = await postWallet('history', { offset });
      const rows = Array.isArray(result.history) ? result.history.slice(0, 50).map(rechargeDto).filter(Boolean) : [];
      return toolResult({ history: rows, total: finite(result.total), offset, limit: finite(result.limit) });
    }
    if (name === 'aitotokens_create_checkout') {
      if (args.confirmed !== true || !rechargePackageCents.includes(args.usdCents)) return errorResult('Confirme com o usuário um dos pacotes disponíveis antes de gerar o link.');
      const result = await postWallet('checkout', { usdCents: args.usdCents });
      const url = checkoutUrl(result.url);
      if (!url || typeof result.orderNsu !== 'string' || !orderPattern.test(result.orderNsu)) throw requestError();
      const usdCents = finite(result.usdCents);
      const brlCents = finite(result.brlCents);
      const amount = brlCents === undefined ? '' : ` Valor do checkout ${brl.format(brlCents / 100)}.`;
      return toolResult({ url, orderNsu: result.orderNsu, usdCents, brlCents },
        `Abra <${url}> para concluir o pagamento na InfinitePay.${amount} Pedido ${result.orderNsu}.`);
    }
    if (typeof args.orderNsu !== 'string' || !orderPattern.test(args.orderNsu)) return errorResult('Informe o identificador válido do pedido.');
    const result = rechargeDto(await postWallet('confirm', { orderNsu: args.orderNsu }));
    if (!result) throw requestError();
    return toolResult(result);
  }

  return async function dispatch(request) {
    const id = request?.id ?? null;
    const ok = result => ({ jsonrpc: '2.0', id, result });
    const fail = (code, message) => ({ jsonrpc: '2.0', id, error: { code, message } });
    if (!asObject(request) || request.jsonrpc !== '2.0' || typeof request.method !== 'string' ||
        (Object.hasOwn(request, 'id') && typeof request.id !== 'string' && !Number.isSafeInteger(request.id))) {
      return fail(-32600, 'Invalid Request');
    }
    if (!Object.hasOwn(request, 'id')) return undefined;
    if (request.method === 'initialize') {
      const protocol = request.params?.protocolVersion;
      return ok({ protocolVersion: supportedProtocols.includes(protocol) ? protocol : supportedProtocols[0],
        capabilities: { tools: {} }, instructions: spendingInstructions,
        serverInfo: { name: 'aitotokens', title: 'AitoIA', version: pluginVersion } });
    }
    if (request.method === 'ping') return ok({});
    if (request.method === 'tools/list') return ok({ tools });
    if (request.method === 'tools/call') {
      try { return ok(await toolCall(request.params?.name, request.params?.arguments ?? {})); }
      catch (error) { return ok(errorResult(error.message)); }
    }
    return fail(-32601, 'Method not found');
  };
}

async function run() {
  const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
  const send = value => { if (value) process.stdout.write(JSON.stringify(value) + '\n'); };
  const tasks = new Set();
  const dispatch = createDispatcher();
  for await (const line of input) {
    let request;
    try { request = JSON.parse(line); }
    catch {
      send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } });
      continue;
    }
    if (request?.method !== 'tools/call') {
      send(await dispatch(request));
      continue;
    }
    const task = dispatch(request).then(send).finally(() => tasks.delete(task));
    tasks.add(task);
  }
  await Promise.all(tasks);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) await run();
