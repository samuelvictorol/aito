import { createInterface } from 'node:readline';
import { pathToFileURL } from 'node:url';
import { randomUUID } from 'node:crypto';
import { createHiggsfieldTools, higgsfieldTools } from './higgsfield.mjs';

const apiBase = 'https://api.aitosoftwares.com/aito-tokens';
const packages = [500, 1500, 5000, 10000];
const supportedProtocols = ['2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'];
const orderPattern = /^aito-tokens-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const readOnly = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true };
const tools = [
  {
    name: 'aitotokens_status',
    description: 'Consulta o saldo e o estado da AitoKey e lista os pacotes de recarga.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_usage',
    description: 'Consulta o consumo de AitoTokens do Codex nos últimos 30 dias.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_recharge_history',
    description: 'Consulta as recargas desta carteira, com paginação.',
    inputSchema: { type: 'object', properties: { offset: { type: 'integer', minimum: 0, maximum: 100000 } }, additionalProperties: false },
    annotations: readOnly,
  },
  {
    name: 'aitotokens_create_checkout',
    description: 'Gera um link de recarga da InfinitePay depois que o usuário confirma o pacote. O usuário abre e paga o link.',
    inputSchema: { type: 'object', required: ['usdCents', 'confirmed'], properties: {
      usdCents: { type: 'integer', enum: packages },
      confirmed: { type: 'boolean', const: true, description: 'O usuário confirmou expressamente a criação do link neste chat.' },
    }, additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  },
  {
    name: 'aitotokens_recharge_status',
    description: 'Consulta a confirmação da InfinitePay para um pedido desta carteira.',
    inputSchema: { type: 'object', required: ['orderNsu'], properties: {
      orderNsu: { type: 'string', maxLength: 48, pattern: orderPattern.source },
    }, additionalProperties: false },
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  },
  ...higgsfieldTools,
];

const asObject = value => value && typeof value === 'object' && !Array.isArray(value);
const finite = value => Number.isFinite(value) && value >= 0 ? value : undefined;
const timestamp = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(value) ? value : undefined;
const currency = code => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: code, maximumFractionDigits: 4 });
const usd = currency('USD');
const brl = currency('BRL');

function checkoutUrl(value) {
  if (typeof value !== 'string' || value.length > 2048) return undefined;
  try {
    const url = new URL(value);
    if (url.protocol === 'https:' && !url.username && !url.password && !url.port &&
        /(^|\.)infinitepay\.(io|com\.br)$/.test(url.hostname)) return url.href;
  } catch { /* The checkout is unavailable. */ }
}

function chargeStatus(value) {
  return ['pending', 'paid', 'expired', 'failed'].includes(value) ? value : 'unavailable';
}

function rechargeDto(row) {
  if (!asObject(row) || typeof row.orderNsu !== 'string' || !orderPattern.test(row.orderNsu)) return undefined;
  return { orderNsu: row.orderNsu, usdCents: finite(row.usdCents), brlCents: finite(row.brlCents),
    status: chargeStatus(row.status), createdAt: timestamp(row.createdAt), paidAt: timestamp(row.paidAt) };
}

function toolResult(data, message) {
  return { content: [{ type: 'text', text: message || JSON.stringify(data) }], structuredContent: data };
}

function errorResult(message) {
  return { isError: true, content: [{ type: 'text', text: message }] };
}

function requestError(status, code) {
  if (code === 'quote_expired_or_changed') return Error('O prazo ou preço da cotação mudou. Consulte e confirme o novo valor.');
  if (code === 'endpoint_unavailable') return Error('O recurso ainda não está habilitado para o piloto.');
  if (status === 401 || status === 403) return Error('AitoKey inválida, revogada ou sem acesso à carteira.');
  if (status === 402) return Error('Saldo insuficiente. Consulte a carteira ou faça uma recarga.');
  if (status === 404) return Error('O recurso solicitado está indisponível para esta carteira.');
  if (status === 409) return Error('A operação aguarda confirmação ou conciliação. Consulte o estado antes de fazer outro pedido.');
  if (status === 422) return Error('Os dados enviados são inválidos ou a cotação expirou.');
  if (status === 429) return Error('Aguarde antes de fazer uma nova consulta à AitoSoftwares.');
  if (status === 503) return Error('O serviço de AitoTokens está temporariamente indisponível.');
  return Error('A AitoSoftwares não conseguiu concluir a solicitação.');
}

export function createDispatcher({ apiKey = process.env.AITO_CODEX_API_KEY, fetcher = globalThis.fetch, sendRequest } = {}) {
  let supportsConfirmation = false;
  const walletPath = /^aito_usr_/.test(apiKey || '') ? '/codex/v1/account/' : '/runtime/';

  async function post(path, body = {}) {
    if (typeof apiKey !== 'string' || !/^aito_(?:usr|prj)_[A-Za-z0-9_-]{48}$/.test(apiKey)) {
      throw Error('Configure a variável local AITO_CODEX_API_KEY antes de iniciar o Codex. Não cole a chave na conversa.');
    }
    let response;
    try {
      response = await fetcher(apiBase + path, {
        method: 'POST', headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify(body), redirect: 'error', signal: AbortSignal.timeout(path.endsWith('/generate') ? 28000 : 18000),
      });
    } catch { throw requestError(503); }
    const result = await response.json().catch(() => null);
    if (!response.ok) throw requestError(response.status, result?.error?.code);
    if (!asObject(result?.data)) throw requestError();
    return result.data;
  }

  const callHiggsfield = createHiggsfieldTools({ post, toolResult, errorResult, async confirm(message, expires) {
    if (!sendRequest || !supportsConfirmation) throw Error('Use uma sessão do Codex que permita confirmações MCP para gerar o vídeo.');
    const answer = await sendRequest('elicitation/create', { message, requestedSchema: { type: 'object',
      properties: { approve: { type: 'boolean', title: 'Autorizar o débito' } }, required: ['approve'] } }, expires);
    return answer?.action === 'accept' && answer.content?.approve === true;
  } });

  async function toolCall(name, args) {
    const tool = tools.find(item => item.name === name);
    if (!tool) return errorResult('Ferramenta AitoTokens desconhecida.');
    if (!asObject(args) || Object.keys(args).some(key => !Object.hasOwn(tool.inputSchema.properties, key))) {
      return errorResult('Parâmetros inválidos.');
    }
    if (name.startsWith('aito_higgsfield_')) return callHiggsfield(name, args);
    if (name === 'aitotokens_status') {
      const result = await post(walletPath + 'status');
      const balanceUsd = finite(result.balanceUsd);
      const balanceBrl = finite(result.balanceBrl);
      const data = { credential: 'active', balanceUsd, balanceBrl, approximateTokens: finite(result.approximateTokens),
        canUse: result.canUse === true, lowBalance: result.lowBalance === true, checkoutConfigured: result.checkoutConfigured === true,
        plans: Array.isArray(result.plans) ? result.plans.filter(plan => packages.includes(plan?.usdCents)).map(plan => ({
          usdCents: plan.usdCents, brlCents: finite(plan.brlCents), approximateTokens: finite(plan.approximateTokens),
        })) : [] };
      const warning = balanceUsd === 0 ? 'Saldo zerado.' : data.lowBalance ? 'Saldo próximo de acabar.' : '';
      return toolResult(data, ['AitoKey ativa.', balanceUsd !== undefined && balanceBrl !== undefined
        ? `Saldo de ${usd.format(balanceUsd)} (${brl.format(balanceBrl)}).` : '',
        data.approximateTokens !== undefined ? `Estimativa de ${data.approximateTokens.toLocaleString('pt-BR')} tokens.` : '', warning].filter(Boolean).join(' '));
    }
    if (name === 'aitotokens_usage') {
      const result = await post('/codex/v1/account/usage');
      const data = { periodDays: finite(result.periodDays), requests: finite(result.requests),
        inputTokens: finite(result.inputTokens), outputTokens: finite(result.outputTokens), cachedTokens: finite(result.cachedTokens),
        billedUsdCents: finite(result.billedUsdCents), billedBrlCents: finite(result.billedBrlCents),
        bySource: Array.isArray(result.bySource) ? result.bySource.filter(row => ['codex_openai', 'codex_higgsfield'].includes(row?.source)).map(row => ({
          source: row.source, requests: finite(row.requests), billedUsdCents: finite(row.billedUsdCents), billedBrlCents: finite(row.billedBrlCents),
        })) : [] };
      return toolResult(data);
    }
    if (name === 'aitotokens_recharge_history') {
      const { offset = 0 } = args;
      if (!Number.isSafeInteger(offset) || offset < 0 || offset > 100000) return errorResult('Informe um deslocamento entre 0 e 100000.');
      const result = await post(walletPath + 'history', { offset });
      const rows = Array.isArray(result.history) ? result.history.slice(0, 50).map(rechargeDto).filter(Boolean) : [];
      return toolResult({ history: rows, total: finite(result.total), offset, limit: finite(result.limit) });
    }
    if (name === 'aitotokens_create_checkout') {
      if (args.confirmed !== true || !packages.includes(args.usdCents)) return errorResult('Confirme com o usuário um dos pacotes disponíveis antes de gerar o link.');
      const result = await post(walletPath + 'checkout', { usdCents: args.usdCents });
      const url = checkoutUrl(result.url);
      if (!url || typeof result.orderNsu !== 'string' || !orderPattern.test(result.orderNsu)) throw requestError();
      return toolResult({ url, orderNsu: result.orderNsu }, `Abra <${url}> para concluir o pagamento na InfinitePay. Pedido ${result.orderNsu}.`);
    }
    if (typeof args.orderNsu !== 'string' || !orderPattern.test(args.orderNsu)) return errorResult('Informe o identificador válido do pedido.');
    const result = rechargeDto(await post(walletPath + 'confirm', { orderNsu: args.orderNsu }));
    if (!result) throw requestError();
    return toolResult(result);
  }

  return async function dispatch(request) {
    const id = request?.id ?? null;
    const ok = result => ({ jsonrpc: '2.0', id, result });
    const fail = (code, message) => ({ jsonrpc: '2.0', id, error: { code, message } });
    if (!asObject(request) || request.jsonrpc !== '2.0' || typeof request.method !== 'string' ||
        (Object.hasOwn(request, 'id') && typeof request.id !== 'string' && !Number.isSafeInteger(request.id))) {
      return fail(-32600, 'Invalid Request');
    }
    if (!Object.hasOwn(request, 'id')) return undefined;
    if (request.method === 'initialize') {
      const protocol = request.params?.protocolVersion;
      const elicitation = request.params?.capabilities?.elicitation;
      supportsConfirmation = asObject(elicitation) && (Object.keys(elicitation).length === 0 || asObject(elicitation.form));
      return ok({ protocolVersion: supportedProtocols.includes(protocol) ? protocol : supportedProtocols[0],
        capabilities: { tools: {} }, serverInfo: { name: 'aitotokens', version: '0.2.1' } });
    }
    if (request.method === 'ping') return ok({});
    if (request.method === 'tools/list') return ok({ tools });
    if (request.method === 'tools/call') {
      try { return ok(await toolCall(request.params?.name, request.params?.arguments ?? {})); }
      catch (error) { return ok(errorResult(error.message)); }
    }
    return fail(-32601, 'Method not found');
  };
}

async function run() {
  const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
  const send = value => { if (value) process.stdout.write(JSON.stringify(value) + '\n'); };
  const pending = new Map();
  const tasks = new Set();
  const dispatch = createDispatcher({ sendRequest(method, params, expires) {
    return new Promise(resolve => {
      const id = `approval-${randomUUID()}`;
      const complete = value => {
        clearTimeout(timeout);
        pending.delete(id);
        resolve(value);
      };
      const timeout = setTimeout(complete, Math.max(0, Math.min(30000, expires - Date.now())));
      pending.set(id, complete);
      send({ jsonrpc: '2.0', id, method, params });
    });
  } });
  for await (const line of input) {
    let request;
    try { request = JSON.parse(line); }
    catch {
      send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } });
      continue;
    }
    if (request?.jsonrpc === '2.0' && !request.method && pending.has(request.id)) {
      pending.get(request.id)(request.error ? undefined : request.result);
      continue;
    }
    if (request?.method !== 'tools/call') {
      send(await dispatch(request));
      continue;
    }
    const task = dispatch(request).then(send).finally(() => tasks.delete(task));
    tasks.add(task);
  }
  for (const complete of pending.values()) complete();
  await Promise.all(tasks);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) await run();
