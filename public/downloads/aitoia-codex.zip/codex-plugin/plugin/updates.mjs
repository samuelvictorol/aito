import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

export const pluginVersion = JSON.parse(readFileSync(new URL('./.codex-plugin/plugin.json', import.meta.url), 'utf8')).version;
const manifestUrl = 'https://aitosoftwares.com/downloads/aitoia-codex.json';
const archiveUrl = 'https://aitosoftwares.com/downloads/aitoia-codex.zip';
const versionPattern = /^(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})$/;
const hashPattern = /^[a-f0-9]{64}$/i;

function newerVersion(candidate, installed) {
  const parts = candidate.split('.').map(Number);
  const old = installed.split('.').map(Number);
  const changed = parts.findIndex((part, index) => part !== old[index]);
  return changed !== -1 && parts[changed] > old[changed];
}

async function fetchBytes(fetcher, url, maximum, timeout) {
  const response = await fetcher(url, {
    redirect: 'error',
    cache: 'no-store',
    signal: AbortSignal.timeout(timeout),
  });
  if (!response.ok || response.redirected || !response.body || Number(response.headers.get('content-length')) > maximum) {
    await response.body?.cancel().catch(() => {});
    throw Error('Falha ao ler o arquivo oficial de atualização.');
  }
  const reader = response.body.getReader();
  const chunks = [];
  let received = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      received += value.byteLength;
      if (received > maximum) throw Error('Arquivo de atualização muito grande.');
      chunks.push(value);
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  return Buffer.concat(chunks, received);
}

export async function checkPluginUpdate({ fetcher = globalThis.fetch, installedVersion = pluginVersion } = {}) {
  if (!versionPattern.test(installedVersion)) throw Error('Versão instalada inválida.');
  const content = await fetchBytes(fetcher, manifestUrl, 4096, 2500);
  const manifest = JSON.parse(content.toString('utf8'));
  const { version, sha256 } = manifest ?? {};
  if (typeof version !== 'string' || !versionPattern.test(version) || typeof sha256 !== 'string' || !hashPattern.test(sha256)) {
    throw Error('A versão publicada pela AitoSoftwares está indisponível.');
  }
  return {
    installedVersion,
    available: newerVersion(version, installedVersion),
    latestVersion: version,
    sha256: sha256.toLowerCase(),
    downloadUrl: archiveUrl + '?v=' + version,
  };
}

export async function downloadVerifiedUpdate(release, path, { fetcher = globalThis.fetch } = {}) {
  const current = await checkPluginUpdate({ fetcher });
  if (!current.available || current.latestVersion !== release.latestVersion || current.sha256 !== release.sha256) {
    throw Error('A versão oficial mudou. Confira novamente antes de baixar.');
  }
  const archive = await fetchBytes(fetcher, current.downloadUrl, 25 * 1024 * 1024, 30_000);
  const hash = createHash('sha256').update(archive).digest('hex');
  if (hash !== current.sha256) throw Error('O ZIP não corresponde ao SHA-256 publicado pela AitoSoftwares.');
  await writeFile(path, archive, { flag: 'wx' });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [operation, version, sha256, path] = process.argv.slice(2);
  try {
    if (operation === 'check') {
      process.stdout.write(JSON.stringify(await checkPluginUpdate()) + '\n');
    } else if (operation === 'download' && typeof path === 'string') {
      await downloadVerifiedUpdate({ latestVersion: version, sha256 }, path);
    } else {
      throw Error('Use o iniciador oficial do AitoIA.');
    }
  } catch {
    process.exitCode = 1;
  }
}
