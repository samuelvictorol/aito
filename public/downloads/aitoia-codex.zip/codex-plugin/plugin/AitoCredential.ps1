[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Ensure', 'Replace', 'Read', 'Check')]
    [string]$Mode,
    [switch]$Gui,
    [System.Security.SecureString]$Secret
)

$ErrorActionPreference = 'Stop'
$keyFormat = '\Aaito_(?:usr|prj)_[A-Za-z0-9_-]{48}\z'

if ($Mode -eq 'Read' -and ![Console]::IsOutputRedirected) {
    throw 'A leitura da AitoKey e reservada a integracoes locais com saida protegida.'
}

if (!('AitoSoftwares.Codex.WindowsCredential' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace AitoSoftwares.Codex {
    public static class WindowsCredential {
        private const string Target = "AitoSoftwares.Codex.AitoTokens.v1";
        private const uint Generic = 1;
        private const uint LocalMachine = 2;
        private const int NotFound = 1168;
        private const int KeyBytes = 114;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct Credential {
            public uint Flags;
            public uint Type;
            public string TargetName;
            public string Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public uint BlobSize;
            public IntPtr Blob;
            public uint Persist;
            public uint AttributeCount;
            public IntPtr Attributes;
            public string TargetAlias;
            public string UserName;
        }

        [DllImport("Advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);

        [DllImport("Advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredWrite(ref Credential credential, uint flags);

        [DllImport("Advapi32.dll")]
        private static extern void CredFree(IntPtr credential);

        [DllImport("Kernel32.dll")]
        private static extern IntPtr GetStdHandle(int handle);

        [DllImport("Kernel32.dll")]
        private static extern uint GetFileType(IntPtr handle);

        public static bool HasPipeOutput() {
            return GetFileType(GetStdHandle(-11)) == 3;
        }

        public static string Read() {
            IntPtr pointer;
            if (!CredRead(Target, Generic, 0, out pointer)) {
                int error = Marshal.GetLastWin32Error();
                if (error == NotFound) return null;
                throw new Win32Exception(error, "Windows Credential Manager read failed.");
            }
            try {
                var credential = (Credential)Marshal.PtrToStructure(pointer, typeof(Credential));
                if (credential.BlobSize != KeyBytes || credential.Blob == IntPtr.Zero) return String.Empty;
                try {
                    return Marshal.PtrToStringUni(credential.Blob, KeyBytes / sizeof(char));
                } finally {
                    for (int i = 0; i < KeyBytes; i++) Marshal.WriteByte(credential.Blob, i, 0);
                }
            } finally {
                CredFree(pointer);
            }
        }

        public static void Write(string key) {
            var pointer = Marshal.StringToCoTaskMemUni(key);
            try {
                var credential = new Credential {
                    Type = Generic,
                    TargetName = Target,
                    Comment = "AitoTokens for Codex",
                    BlobSize = (uint)(key.Length * sizeof(char)),
                    Blob = pointer,
                    Persist = LocalMachine,
                    UserName = "AitoSoftwares"
                };
                if (!CredWrite(ref credential, 0)) {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows Credential Manager write failed.");
                }
            } finally {
                Marshal.ZeroFreeCoTaskMemUnicode(pointer);
            }
        }
    }
}
'@
}

function Read-AitoKeyDialog {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $dialog = New-Object System.Windows.Forms.Form
    try {
        $dialog.Text = 'AitoIA - Codex | Conectar AitoTokens'
        $dialog.StartPosition = 'CenterScreen'
        $dialog.FormBorderStyle = 'FixedDialog'
        $dialog.ClientSize = New-Object System.Drawing.Size(490, 172)
        $dialog.MinimizeBox = $false
        $dialog.MaximizeBox = $false
        $dialog.AutoScaleMode = 'Dpi'

        $label = New-Object System.Windows.Forms.Label
        $label.Text = "Cole a sua AitoKey de Meus dados na AitoSoftwares.`r`nEla sera guardada no Gerenciador de Credenciais do Windows."
        $label.Location = New-Object System.Drawing.Point(16, 17)
        $label.Size = New-Object System.Drawing.Size(460, 44)

        $entry = New-Object System.Windows.Forms.TextBox
        $entry.UseSystemPasswordChar = $true
        $entry.MaxLength = 256
        $entry.AccessibleName = 'AitoKey'
        $entry.Location = New-Object System.Drawing.Point(16, 67)
        $entry.Size = New-Object System.Drawing.Size(455, 24)

        $save = New-Object System.Windows.Forms.Button
        $save.Text = 'Conectar'
        $save.DialogResult = 'OK'
        $save.Location = New-Object System.Drawing.Point(271, 116)
        $save.Size = New-Object System.Drawing.Size(92, 34)

        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Text = 'Cancelar'
        $cancel.DialogResult = 'Cancel'
        $cancel.Location = New-Object System.Drawing.Point(379, 116)
        $cancel.Size = New-Object System.Drawing.Size(92, 34)

        $dialog.Controls.AddRange(@($label, $entry, $save, $cancel))
        $dialog.AcceptButton = $save
        $dialog.CancelButton = $cancel
        $dialog.ActiveControl = $entry
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            throw 'Configuracao da AitoKey cancelada.'
        }
        if ([string]::IsNullOrWhiteSpace($entry.Text)) { throw 'Informe sua AitoKey.' }
        $characters = $entry.Text.ToCharArray()
        try {
            $entered = [System.Security.SecureString]::new()
            foreach ($character in $characters) { $entered.AppendChar($character) }
            $entered.MakeReadOnly()
            return $entered
        } finally {
            [Array]::Clear($characters, 0, $characters.Length)
        }
    } finally {
        if ($entry) { $entry.Clear() }
        $dialog.Dispose()
    }
}

if ($Mode -eq 'Read' -and ![AitoSoftwares.Codex.WindowsCredential]::HasPipeOutput()) {
    throw 'A leitura da AitoKey exige uma conexao privada com o processo do Codex.'
}

if ($Mode -ne 'Replace') {
    $stored = [AitoSoftwares.Codex.WindowsCredential]::Read()
    if ($null -ne $stored) {
        if ($stored -cnotmatch $keyFormat) {
            throw 'A AitoKey salva tem formato invalido. Use a opcao de trocar a chave no iniciador AitoIA.'
        }
        if ($Mode -eq 'Read') { [Console]::WriteLine($stored) }
        return
    }
    if ($Mode -ne 'Ensure') {
        throw 'AitoKey ausente. Abra o atalho AitoIA - Codex para conectar a carteira.'
    }
}

$disposeSecret = !$Secret
$key = $null
try {
    if (!$Secret) {
        $Secret = if ($Gui) { Read-AitoKeyDialog } else { Read-Host 'AitoKey (oculta)' -AsSecureString }
    }
    $key = [System.Net.NetworkCredential]::new('', $Secret).Password.Trim()
    if ($key -cnotmatch $keyFormat) {
        throw 'Formato de AitoKey invalido. Copie a chave completa em Meus dados na AitoSoftwares.'
    }
    [AitoSoftwares.Codex.WindowsCredential]::Write($key)
} finally {
    $key = $null
    if ($disposeSecret -and $Secret) { $Secret.Dispose() }
}
