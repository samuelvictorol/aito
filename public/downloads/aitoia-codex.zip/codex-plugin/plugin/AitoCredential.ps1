[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Ensure', 'Replace', 'Read', 'Check', 'Remove')]
    [string]$Mode,
    [switch]$Gui,
    [switch]$Verify,
    [System.Security.SecureString]$Secret
)

$ErrorActionPreference = 'Stop'
$keyFormat = '\Aaito_(?:usr|prj)_[A-Za-z0-9_-]{48}\z'
$profileUrl = 'https://aitosoftwares.com/app?tab=profile'

if ($Mode -eq 'Read' -and ![Console]::IsOutputRedirected) {
    throw 'A leitura da AitoKey e reservada a integracoes locais com saida protegida.'
}

if (!('AitoSoftwares.Codex.WindowsCredential' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace AitoSoftwares.Codex {
    public static class WindowsCredential {
        private const string Target = "AitoSoftwares.Codex.AitoTokens.v1";
        private const uint Generic = 1;
        private const uint LocalMachine = 2;
        private const int NotFound = 1168;
        private const int KeyBytes = 114;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct Credential {
            public uint Flags;
            public uint Type;
            public string TargetName;
            public string Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public uint BlobSize;
            public IntPtr Blob;
            public uint Persist;
            public uint AttributeCount;
            public IntPtr Attributes;
            public string TargetAlias;
            public string UserName;
        }

        [DllImport("Advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);

        [DllImport("Advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredWrite(ref Credential credential, uint flags);

        [DllImport("Advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CredDelete(string target, uint type, uint flags);

        [DllImport("Advapi32.dll")]
        private static extern void CredFree(IntPtr credential);

        [DllImport("Kernel32.dll")]
        private static extern IntPtr GetStdHandle(int handle);

        [DllImport("Kernel32.dll")]
        private static extern uint GetFileType(IntPtr handle);

        public static bool HasPipeOutput() {
            return GetFileType(GetStdHandle(-11)) == 3;
        }

        public static string Read() {
            IntPtr pointer;
            if (!CredRead(Target, Generic, 0, out pointer)) {
                int error = Marshal.GetLastWin32Error();
                if (error == NotFound) return null;
                throw new Win32Exception(error, "Windows Credential Manager read failed.");
            }
            try {
                var credential = (Credential)Marshal.PtrToStructure(pointer, typeof(Credential));
                if (credential.BlobSize != KeyBytes || credential.Blob == IntPtr.Zero) return String.Empty;
                try {
                    return Marshal.PtrToStringUni(credential.Blob, KeyBytes / sizeof(char));
                } finally {
                    for (int i = 0; i < KeyBytes; i++) Marshal.WriteByte(credential.Blob, i, 0);
                }
            } finally {
                CredFree(pointer);
            }
        }

        public static void Write(string key) {
            var pointer = Marshal.StringToCoTaskMemUni(key);
            try {
                var credential = new Credential {
                    Type = Generic,
                    TargetName = Target,
                    Comment = "AitoTokens for Codex",
                    BlobSize = (uint)(key.Length * sizeof(char)),
                    Blob = pointer,
                    Persist = LocalMachine,
                    UserName = "AitoSoftwares"
                };
                if (!CredWrite(ref credential, 0)) {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows Credential Manager write failed.");
                }
            } finally {
                Marshal.ZeroFreeCoTaskMemUnicode(pointer);
            }
        }

        public static void Remove() {
            if (CredDelete(Target, Generic, 0)) return;
            int error = Marshal.GetLastWin32Error();
            if (error != NotFound) throw new Win32Exception(error, "Windows Credential Manager deletion failed.");
        }
    }
}
'@
}

if ($Mode -eq 'Remove') {
    [AitoSoftwares.Codex.WindowsCredential]::Remove()
    return
}

function Get-AitoKeyStatus {
    param([Parameter(Mandatory = $true)][string]$Key)

    $previousTls = [Net.ServicePointManager]::SecurityProtocol
    $response = $null
    try {
        [Net.ServicePointManager]::SecurityProtocol = $previousTls -bor [Net.SecurityProtocolType]::Tls12
        $request = [Net.WebRequest]::Create('https://api.aitosoftwares.com/aito-tokens/codex/v1/credentials/check')
        $request.Method = 'POST'
        $request.ContentLength = 0
        $request.AllowAutoRedirect = $false
        $request.Timeout = 8000
        $request.ReadWriteTimeout = 8000
        $request.Accept = 'application/json'
        $request.Headers['Authorization'] = 'Bearer ' + $Key
        try { $response = $request.GetResponse() } catch [Net.WebException] { $response = $_.Exception.Response }
        if (!$response) { return 'Unavailable' }
        $status = [int]$response.StatusCode
        if ($status -eq 204) { return 'Active' }
        if ($status -notin @(401, 403)) { return 'Unavailable' }

        $reader = [IO.StreamReader]::new($response.GetResponseStream())
        $buffer = [char[]]::new(4096)
        try { $count = $reader.ReadBlock($buffer, 0, $buffer.Length) } finally { $reader.Dispose() }
        if ($count -eq $buffer.Length) { return 'Unavailable' }
        $body = [string]::new($buffer, 0, $count) | ConvertFrom-Json -ErrorAction Stop
        switch ($body.error.code) {
            'invalid_api_key' { return 'Rejected' }
            'wallet_unavailable' { return 'WalletUnavailable' }
            'codex_access_denied' { return 'AccessDenied' }
        }
    } catch { return 'Unavailable' } finally {
        if ($response) { $response.Dispose() }
        [Net.ServicePointManager]::SecurityProtocol = $previousTls
    }
    return 'Unavailable'
}

function Read-AitoKeyDialog {
    param([string]$Reason)

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $dialog = New-Object System.Windows.Forms.Form
    try {
        $dialog.Text = 'AitoIA - Codex | Conectar AitoTokens'
        $dialog.StartPosition = 'CenterScreen'
        $dialog.FormBorderStyle = 'FixedDialog'
        $dialog.ClientSize = New-Object System.Drawing.Size(490, 204)
        $dialog.MinimizeBox = $false
        $dialog.MaximizeBox = $false
        $dialog.AutoScaleMode = 'Dpi'

        $label = New-Object System.Windows.Forms.Label
        $label.Text = (@($Reason, 'Cole a AitoKey de Meus dados na AitoSoftwares.',
            'Ela sera guardada no Gerenciador de Credenciais do Windows.') -ne '') -join "`r`n"
        $label.Location = New-Object System.Drawing.Point(16, 17)
        $label.Size = New-Object System.Drawing.Size(460, 65)

        $entry = New-Object System.Windows.Forms.TextBox
        $entry.UseSystemPasswordChar = $true
        $entry.MaxLength = 256
        $entry.AccessibleName = 'AitoKey'
        $entry.Location = New-Object System.Drawing.Point(16, 98)
        $entry.Size = New-Object System.Drawing.Size(455, 24)

        $save = New-Object System.Windows.Forms.Button
        $save.Text = 'Conectar'
        $save.DialogResult = 'OK'
        $save.Location = New-Object System.Drawing.Point(271, 147)
        $save.Size = New-Object System.Drawing.Size(92, 34)

        $cancel = New-Object System.Windows.Forms.Button
        $cancel.Text = 'Cancelar'
        $cancel.DialogResult = 'Cancel'
        $cancel.Location = New-Object System.Drawing.Point(379, 147)
        $cancel.Size = New-Object System.Drawing.Size(92, 34)

        $profile = New-Object System.Windows.Forms.Button
        $profile.Text = 'Abrir Meus dados'
        $profile.Location = New-Object System.Drawing.Point(16, 147)
        $profile.Size = New-Object System.Drawing.Size(135, 34)
        $profile.Add_Click({ Start-Process $profileUrl })

        $dialog.Controls.AddRange(@($label, $entry, $profile, $save, $cancel))
        $dialog.AcceptButton = $save
        $dialog.CancelButton = $cancel
        $dialog.ActiveControl = $entry
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            throw [OperationCanceledException]::new('Configuracao da AitoKey cancelada.')
        }
        if ([string]::IsNullOrWhiteSpace($entry.Text)) { throw 'Informe sua AitoKey.' }
        $characters = $entry.Text.ToCharArray()
        try {
            $entered = [System.Security.SecureString]::new()
            foreach ($character in $characters) { $entered.AppendChar($character) }
            $entered.MakeReadOnly()
            return $entered
        } finally {
            [Array]::Clear($characters, 0, $characters.Length)
        }
    } finally {
        if ($entry) { $entry.Clear() }
        $dialog.Dispose()
    }
}

if ($Mode -eq 'Read' -and ![AitoSoftwares.Codex.WindowsCredential]::HasPipeOutput()) {
    throw 'A leitura da AitoKey exige uma conexao privada com o processo do Codex.'
}

$dialogReason = ''
if ($Mode -ne 'Replace') {
    $stored = [AitoSoftwares.Codex.WindowsCredential]::Read()
    if ($null -ne $stored) {
        if ($stored -cnotmatch $keyFormat -and ($Mode -ne 'Ensure' -or !$Verify)) {
            throw 'A AitoKey salva tem formato invalido. Abra Trocar AitoKey.bat ou o atalho AitoIA - Codex.'
        }
        if ($Mode -eq 'Read') { [Console]::WriteLine($stored); return }
        if ($Mode -eq 'Check' -or !$Verify) { return }

        $status = if ($stored -cmatch $keyFormat) { Get-AitoKeyStatus -Key $stored } else { 'Rejected' }
        switch ($status) {
            'Active' { return }
            'Rejected' { $dialogReason = 'A AitoKey salva expirou ou foi revogada. Use a chave atual.' }
            'WalletUnavailable' { $dialogReason = 'Carteira indisponivel. Confira a licenca ou use a chave de uma carteira ativa.' }
            'AccessDenied' { throw 'O acesso ao Codex esta bloqueado para esta carteira. Confira Meus dados na AitoSoftwares.' }
            default { Write-Warning 'Nao foi possivel validar a AitoKey agora. A chave salva foi mantida.'; return }
        }
    }
    if ($Mode -ne 'Ensure') {
        throw 'AitoKey ausente. Abra o atalho AitoIA - Codex para conectar a carteira.'
    }
}

$disposeSecret = !$Secret
$key = $null
try {
    if (!$Secret) {
        if ($dialogReason -and !$Gui) { Write-Host $dialogReason }
        $Secret = if ($Gui) { Read-AitoKeyDialog -Reason $dialogReason } else { Read-Host 'AitoKey (oculta)' -AsSecureString }
    }
    $key = [System.Net.NetworkCredential]::new('', $Secret).Password.Trim()
    if ($key -cnotmatch $keyFormat) {
        throw 'Formato de AitoKey invalido. Copie a chave completa em Meus dados na AitoSoftwares.'
    }
    if ($Verify) {
        switch (Get-AitoKeyStatus -Key $key) {
            'Active' { break }
            'Rejected' { throw 'A chave informada expirou ou foi revogada. Copie a AitoKey atual em Meus dados.' }
            'WalletUnavailable' { throw 'A carteira desta chave esta indisponivel. Confira a licenca ou selecione uma carteira ativa em Meus dados.' }
            'AccessDenied' { throw 'O acesso ao Codex esta bloqueado para esta carteira. Confira Meus dados na AitoSoftwares.' }
            default { throw 'Nao foi possivel verificar a chave agora. A credencial anterior foi mantida. Tente novamente.' }
        }
    }
    [AitoSoftwares.Codex.WindowsCredential]::Write($key)
} finally {
    $key = $null
    if ($disposeSecret -and $Secret) { $Secret.Dispose() }
}
