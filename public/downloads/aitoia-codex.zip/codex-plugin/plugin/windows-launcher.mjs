import { access, readFile } from 'node:fs/promises';
import { basename, isAbsolute, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const launcherName = 'Iniciar AitoIA.exe';
export const launcherRegistration = () => process.env.LOCALAPPDATA && join(process.env.LOCALAPPDATA, 'AitoSoftwares', 'Codex', 'launcher.json');

export async function resolveNativeLauncher() {
  if (process.platform !== 'win32') return null;
  const local = fileURLToPath(new URL('../' + launcherName, import.meta.url));
  const candidates = [local];
  try {
    const registration = launcherRegistration();
    const metadata = registration && JSON.parse(await readFile(registration, 'utf8'));
    if (typeof metadata?.launcher === 'string' && isAbsolute(metadata.launcher) &&
        basename(metadata.launcher).toLowerCase() === launcherName.toLowerCase()) candidates.push(metadata.launcher);
  } catch { /* The launcher may be used from a newly extracted ZIP. */ }
  for (const candidate of candidates) {
    try { await access(candidate); return candidate; }
    catch { /* Check the next installation location. */ }
  }
  return null;
}
