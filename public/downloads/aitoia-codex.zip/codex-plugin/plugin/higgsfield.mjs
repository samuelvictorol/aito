import { randomUUID } from 'node:crypto';

const apiPath = '/codex/v1/media/higgsfield/';
const identifier = /^[A-Za-z0-9_-]{1,100}$/;
const catalogId = /^[A-Za-z0-9][A-Za-z0-9_.\/-]{0,159}$/;
const statuses = new Set(['queued', 'in_progress', 'completed', 'failed', 'nsfw', 'canceled']);
const readOnly = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true };
const schema = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
const idSchema = { type: 'string', pattern: identifier.source, maxLength: 100 };
const catalogIdSchema = { type: 'string', pattern: catalogId.source, maxLength: 160 };
const promptSchema = { type: 'string', minLength: 1, maxLength: 2000 };

export const higgsfieldTools = [
  { name: 'aito_higgsfield_models', description: 'Lista os modelos e opções de vídeo Higgsfield disponíveis na carteira AitoTokens.',
    inputSchema: schema({}), annotations: readOnly },
  { name: 'aito_higgsfield_quote', description: 'Consulta o preço em dólar e real para um vídeo. Nenhum valor é reservado nesta etapa.',
    inputSchema: schema({ model: catalogIdSchema, option: catalogIdSchema, prompt: promptSchema }, ['model', 'option', 'prompt']), annotations: readOnly },
  { name: 'aito_higgsfield_generate', description: 'Abre uma confirmação de valor no Codex para o usuário e, se aceita, inicia a geração paga com a mesma AitoKey.',
    inputSchema: schema({ quoteId: idSchema }, ['quoteId']),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: true } },
  { name: 'aito_higgsfield_status', description: 'Acompanha uma geração desta carteira. Quando pronta, retorna o link do vídeo.',
    inputSchema: schema({ id: idSchema }, ['id']), annotations: readOnly },
];

const amount = value => Number.isFinite(value) && value >= 0 ? value : undefined;
const label = value => typeof value === 'string' ? value.slice(0, 160) : undefined;
const price = (cents, currency) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency, maximumFractionDigits: 6 }).format(cents / 100);

function videoUrl(value) {
  if (typeof value !== 'string' || value.length > 4096) return undefined;
  try {
    const url = new URL(value);
    if (url.protocol === 'https:' && !url.username && !url.password && !url.port) return url.href;
  } catch { /* The API returned no usable media URL. */ }
}

function generationData(data) {
  if (typeof data.id !== 'string' || !identifier.test(data.id) || !statuses.has(data.status)) {
    throw Error('A API não retornou uma geração válida.');
  }
  return { id: data.id, status: data.status, billedUsdCents: amount(data.billedUsdCents),
    billedBrlCents: amount(data.billedBrlCents), url: data.status === 'completed' ? videoUrl(data.url) : undefined };
}

export function createHiggsfieldTools({ post, confirm, toolResult, errorResult }) {
  const quotes = new Map();

  return async function callHiggsfield(name, args) {
    if (name === 'aito_higgsfield_models') {
      const data = await post(apiPath + 'models');
      const models = Array.isArray(data.models) ? data.models.slice(0, 60).filter(model =>
        typeof model?.id === 'string' && catalogId.test(model.id) && Array.isArray(model.options)).map(model => ({
        id: model.id, label: label(model.label), options: model.options.slice(0, 80).filter(option =>
          typeof option?.id === 'string' && catalogId.test(option.id)).map(option => ({ id: option.id, label: label(option.label),
          seconds: amount(option.seconds), format: label(option.format), resolution: label(option.resolution) })),
      })) : [];
      return toolResult({ models });
    }
    if (name === 'aito_higgsfield_quote') {
      const { model, option, prompt } = args;
      if (typeof model !== 'string' || !catalogId.test(model) || typeof option !== 'string' || !catalogId.test(option) ||
          typeof prompt !== 'string' || prompt.length > promptSchema.maxLength || !prompt.trim()) {
        return errorResult('Informe um modelo, uma opção do catálogo e uma descrição de até 2.000 caracteres.');
      }
      const data = await post(apiPath + 'quote', { model, option, prompt });
      const { id, quoteToken, billedUsdCents, billedBrlCents, expiresAt } = data;
      const expires = Date.parse(expiresAt);
      if (typeof id !== 'string' || !identifier.test(id) || typeof quoteToken !== 'string' || !quoteToken || quoteToken.length > 4096 ||
          !amount(billedUsdCents) || !amount(billedBrlCents) || !Number.isFinite(expires) || expires <= Date.now()) {
        return errorResult('A cotação está indisponível. Nenhuma geração foi iniciada.');
      }
      for (const [id, quote] of quotes) if (quote.expires <= Date.now()) quotes.delete(id);
      if (quotes.size >= 20) return errorResult('Há muitas cotações nesta sessão. Aguarde algumas expirarem.');
      const quoteId = randomUUID();
      quotes.set(quoteId, { model, option, prompt, quoteToken, billedUsdCents, billedBrlCents, expires });
      return toolResult({ quoteId, id, model, option, billedUsdCents, billedBrlCents, expiresAt });
    }
    if (name === 'aito_higgsfield_generate') {
      const quote = quotes.get(args.quoteId);
      if (!quote || quote.expires <= Date.now()) return errorResult('Solicite uma nova cotação de vídeo.');
      if (quote.generation) return toolResult(quote.generation);
      if (quote.pending) return errorResult('Já existe uma confirmação aberta para esta cotação.');
      quote.pending = true;
      try {
        const approved = await confirm(`Autorizar até ${price(quote.billedUsdCents, 'USD')} (${price(quote.billedBrlCents, 'BRL')}) da carteira AitoTokens para o vídeo Higgsfield (${quote.model}, ${quote.option})?`, quote.expires);
        if (!approved) return errorResult('A geração não foi autorizada no Codex.');
        if (quote.expires <= Date.now()) return errorResult('A cotação expirou. Solicite outra antes de gerar.');
        const { model, option, prompt, quoteToken } = quote;
        quote.generation = generationData(await post(apiPath + 'generate', { model, option, prompt, quoteToken }));
        return toolResult(quote.generation);
      } finally { quote.pending = false; }
    }
    if (typeof args.id !== 'string' || !identifier.test(args.id)) return errorResult('Informe o identificador da geração.');
    return toolResult(generationData(await post(apiPath + 'status', { id: args.id })));
  };
}
