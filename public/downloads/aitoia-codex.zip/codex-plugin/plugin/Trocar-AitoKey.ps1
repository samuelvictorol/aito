$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
try {
    & (Join-Path $PSScriptRoot 'AitoCredential.ps1') -Mode Replace -Gui -Verify
    $message = 'AitoKey atualizada. Se o Codex ja estiver aberto, salve o trabalho e reabra pelo atalho AitoIA - Codex.'
    [System.Windows.Forms.MessageBox]::Show($message, 'AitoIA - Codex', 'OK', 'Information') | Out-Null
} catch [System.OperationCanceledException] {
    return
} catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'AitoIA - Codex', 'OK', 'Error') | Out-Null
    exit 1
}
