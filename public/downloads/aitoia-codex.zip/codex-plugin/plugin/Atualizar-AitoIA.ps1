[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$NodePath,
    [switch]$ShowStatus
)

$ErrorActionPreference = 'Stop'
$updateScript = Join-Path $PSScriptRoot 'updates.mjs'
$dialogTitle = 'Atualizar AitoIA'

function Show-AitoUpdateMessage {
    param([string]$Message, [string]$Buttons = 'OK', [string]$Icon = 'Information')
    Add-Type -AssemblyName System.Windows.Forms
    if ($Buttons -eq 'YesNo') {
        return [System.Windows.Forms.MessageBox]::Show($Message, $dialogTitle, $Buttons, $Icon, 'Button2')
    }
    return [System.Windows.Forms.MessageBox]::Show($Message, $dialogTitle, $Buttons, $Icon)
}

function Expand-VerifiedAitoArchive {
    param([string]$ArchivePath, [string]$Destination, [string]$ExpectedVersion)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ArchivePath)
    try {
        $root = [System.IO.Path]::GetFullPath($Destination).TrimEnd('\') + '\'
        $prefixComparison = [System.StringComparison]::OrdinalIgnoreCase
        $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $maximum = 50MB
        $written = 0L
        $buffer = [byte[]]::new(65536)
        if ($archive.Entries.Count -gt 1024) { throw 'ZIP com arquivos demais.' }
        foreach ($entry in $archive.Entries) {
            $entryName = $entry.FullName
            $isDirectory = $entryName.EndsWith('/')
            $relative = $entryName.TrimEnd('/')
            $sections = $relative.Split('/')
            if (($sections.Count -lt 2 -and !$isDirectory) -or $sections[0] -cne 'codex-plugin' -or
                ($sections | Where-Object {
                    !$_ -or $_ -match '[<>:"\\|?*\x00-\x1F]|[. ]$|^(CON|PRN|AUX|NUL|COM[0-9¹²³]|LPT[0-9¹²³])(?:\.|$)'
                }) -or !$seen.Add($relative)) {
                throw 'O ZIP possui um caminho invalido.'
            }
            $attributes = $entry.ExternalAttributes
            $unixType = ($attributes -shr 16) -band 0xf000
            if (($attributes -band 0x0400) -or $unixType -notin @(0, 0x4000, 0x8000)) {
                throw 'O ZIP possui um tipo de arquivo invalido.'
            }
            $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($root, $relative.Replace('/', '\')))
            if (!$target.StartsWith($root, $prefixComparison) -or $entry.Length -gt ($maximum - $written)) {
                throw 'O ZIP nao pode ser extraido com seguranca.'
            }
            if ($isDirectory) {
                if ($entry.Length -ne 0) { throw 'Diretorio invalido no ZIP.' }
                [System.IO.Directory]::CreateDirectory($target) | Out-Null
                continue
            }

            [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($target)) | Out-Null
            $source = $entry.Open()
            try {
                $output = [System.IO.File]::Open($target, 'CreateNew', 'Write', 'None')
                try {
                    $entryBytes = 0L
                    while (($size = $source.Read($buffer, 0, $buffer.Length)) -gt 0) {
                        $entryBytes += $size
                        $written += $size
                        if ($entryBytes -gt $entry.Length -or $written -gt $maximum) {
                            throw 'O tamanho dos arquivos do ZIP e invalido.'
                        }
                        $output.Write($buffer, 0, $size)
                    }
                    if ($entryBytes -ne $entry.Length) { throw 'O ZIP esta incompleto.' }
                } finally {
                    $output.Dispose()
                }
            } finally {
                $source.Dispose()
            }
        }
        $package = Join-Path $Destination 'codex-plugin'
        $manifestFile = Join-Path $package 'plugin\.codex-plugin\plugin.json'
        $manifest = Get-Content -LiteralPath $manifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($manifest.name -cne 'aitosoftwares' -or $manifest.version -cne $ExpectedVersion) {
            throw 'A versao do pacote e diferente da publicada.'
        }
        foreach ($required in @('Iniciar AitoIA.bat', 'Iniciar-AitoIA.ps1', 'Configurar-AitoCodex.mjs', 'plugin\AitoCredential.ps1')) {
            if (!(Test-Path -LiteralPath (Join-Path $package $required) -PathType Leaf)) {
                throw 'O ZIP oficial esta incompleto.'
            }
        }
    } finally {
        $archive.Dispose()
    }
}

function Save-AitoUpdate {
    param($Release)
    $releases = Join-Path $env:LOCALAPPDATA 'AitoSoftwares\Codex\Releases'
    [System.IO.Directory]::CreateDirectory($releases) | Out-Null
    $root = [System.IO.Path]::GetFullPath($releases).TrimEnd('\') + '\'
    $destination = Join-Path $root ('AitoIA-' + $Release.latestVersion + '-' + [Guid]::NewGuid().ToString('N'))
    [System.IO.Directory]::CreateDirectory($destination) | Out-Null
    $archive = Join-Path $destination 'aitoia-codex.zip'
    try {
        & $NodePath $updateScript download $Release.latestVersion $Release.sha256 $archive
        if ($LASTEXITCODE -ne 0) { throw 'O ZIP nao foi confirmado.' }
        Expand-VerifiedAitoArchive -ArchivePath $archive -Destination $destination -ExpectedVersion $Release.latestVersion
        Remove-Item -LiteralPath $archive -Force
        return (Join-Path $destination 'codex-plugin\Iniciar AitoIA.bat')
    } catch {
        if ([System.IO.Path]::GetFullPath($destination).StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction SilentlyContinue
        }
        throw
    }
}

$update = & $NodePath $updateScript check | Out-String
if ($LASTEXITCODE -ne 0) {
    if ($ShowStatus) { Show-AitoUpdateMessage 'Nao foi possivel conferir a versao oficial. Tente novamente mais tarde.' | Out-Null }
    return $false
}
$release = $update | ConvertFrom-Json
if (!$release.available) {
    if ($ShowStatus) { Show-AitoUpdateMessage "O AitoIA $($release.installedVersion) esta atualizado." | Out-Null }
    return $false
}
$notice = "AitoIA $($release.latestVersion) esta disponivel. Baixar e verificar o ZIP oficial agora? Sua AitoKey continua salva no Windows."
if ((Show-AitoUpdateMessage $notice 'YesNo') -ne 'Yes') { return $false }

try {
    $installer = Save-AitoUpdate -Release $release
    Show-AitoUpdateMessage 'ZIP verificado. Encerre o Codex e abra Iniciar AitoIA.bat na pasta que sera mostrada para instalar.' | Out-Null
    Start-Process -FilePath (Join-Path $env:SystemRoot 'explorer.exe') -ArgumentList ('/select,"{0}"' -f $installer)
    return $true
} catch {
    Show-AitoUpdateMessage 'Nao foi possivel verificar ou extrair o ZIP oficial. A versao atual continua instalada.' -Icon 'Warning' | Out-Null
    return $false
}
