---
name: aito-tokens
description: Consulte e recarregue a carteira AitoTokens do Codex, veja o uso de OpenAI e Higgsfield, ou cote e gere vídeos pela AitoKey quando o usuário solicitar.
---

Use as ferramentas do servidor MCP `aitotokens`.

- Para saldo, licença, estimativa de tokens e pacotes, chame `aitotokens_status`. Informe que a estimativa em tokens varia por modelo e pelas proporções de entrada e saída.
- Para consultar o consumo do Codex dos últimos 30 dias, use `aitotokens_usage`. Para recargas anteriores, use `aitotokens_recharge_history`. Para conferir o estado de um pedido específico, use `aitotokens_recharge_status` com o identificador do pedido.
- Quando o usuário pedir para recarregar, consulte os pacotes e informe o valor aproximado em reais. Só chame `aitotokens_create_checkout` após o usuário confirmar qual pacote quer e que deseja gerar o link. Apresente o link para o próprio usuário abrir e pagar.
- Quando o saldo estiver baixo ou insuficiente, explique o estado indicado pela ferramenta e mostre as opções. Trate cada recarga como pendente até a confirmação do pagamento pelo sistema.
- A AitoKey é configurada localmente antes de iniciar o Codex. Se estiver ausente ou revogada, indique que o usuário deve substituir a credencial no ambiente local. Nunca peça que a chave seja colada na conversa.

Para vídeos pagos com AitoTokens:

1. Use `aito_higgsfield_models` para consultar os modelos e formatos que a AitoSoftwares disponibilizou.
2. Use `aito_higgsfield_quote` com o modelo, a opção e a descrição do vídeo. Mostre o valor em dólares e reais antes de prosseguir.
3. A pedido do usuário, use `aito_higgsfield_generate` com o ID da cotação. O Codex solicita confirmação do débito. Em caso de cancelamento, indisponibilidade ou saldo insuficiente, informe o resultado e aguarde instruções. Não envie a solicitação por outro provedor ou plugin.
4. Guarde o ID da geração que a cotação já fornece. Se a solicitação for interrompida ou continuar em fila, use `aito_higgsfield_status` com esse ID antes de tentar gerar outro vídeo. Ao concluir, entregue o link para o usuário abrir ou baixar.
