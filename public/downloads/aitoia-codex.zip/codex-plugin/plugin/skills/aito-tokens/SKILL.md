---
name: aito-tokens
description: Consulte o saldo e o consumo do AitoIA no Codex, faça recargas de AitoTokens, veja o guia de uso ou confira atualizações do plugin.
---

Use as ferramentas do servidor MCP `aitotokens`.

- Antes de iniciar uma tarefa, estime contexto e saída no modelo selecionado com `aitotokens_quote_task`. Apresente a estimativa e aguarde confirmação. Se prever várias chamadas, informe a estimativa total e suas hipóteses. A conversa de cotação também usa o modelo.
- Para gerar imagem com AitoKey, use `aitotokens_quote_image`, mostre o teto de AitoTokens e aguarde aprovação explícita. Depois chame `aitotokens_generate_image` com os mesmos parâmetros, o token da cotação e `confirmed: true`. Esta integração usa a carteira AitoTokens e não pede uma chave OpenAI local.

- Para saldo, licença, estimativa de tokens e pacotes, chame `aitotokens_status`. Informe que a estimativa em tokens varia por modelo e pelas proporções de entrada e saída.
- Para consultar o consumo do Codex dos últimos 30 dias, use `aitotokens_usage`. Para recargas anteriores, use `aitotokens_recharge_history`. Para conferir o estado de um pedido específico, use `aitotokens_recharge_status` com o identificador do pedido.
- Quando o usuário pedir para recarregar, consulte os pacotes e informe o valor aproximado em reais. Só chame `aitotokens_create_checkout` após o usuário confirmar qual pacote quer e que deseja gerar o link. Apresente o link para o próprio usuário abrir e pagar.
- Quando o saldo estiver baixo ou insuficiente, explique o estado indicado pela ferramenta e mostre as opções. Trate cada recarga como pendente até a confirmação do pagamento pelo sistema.
- A AitoKey é configurada localmente antes de iniciar o Codex. Se estiver ausente ou revogada, oriente a copiar a chave atual em Meus dados e abrir o atalho de chave verde **Configurar AitoCodex Key**. Se o usuário pedir «Abra Configurar AitoCodex Key» ou solicitar a janela de troca, chame `aitotokens_reconnect` com `confirmed: true`. Peça que a chave seja informada apenas na janela protegida. Se a carteira estiver indisponível, oriente a conferir a licença ou selecionar outra carteira no painel.
- Para saber como escolher modelos, mencionar o plugin e usar os comandos, chame `aitotokens_help`.
- Para verificar atualização, chame `aitotokens_check_update`. No Windows, chame `aitotokens_open_updater` com `confirmed: true` somente se o usuário pedir expressamente para abrir o atualizador ou confirmar sua abertura. A janela confirma o download. O usuário instala o pacote verificado após encerrar o Codex.
