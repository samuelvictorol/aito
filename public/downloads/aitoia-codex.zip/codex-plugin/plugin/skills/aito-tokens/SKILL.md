---
name: aito-tokens
description: Consulte o saldo e o consumo do AitoIA no Codex, faça recargas de AitoTokens, veja o guia de uso ou confira atualizações do plugin.
---

Use as ferramentas do servidor MCP `aitotokens`.

- Para saldo, licença, estimativa de tokens e pacotes, chame `aitotokens_status`. Informe que a estimativa em tokens varia por modelo e pelas proporções de entrada e saída.
- Para consultar o consumo do Codex dos últimos 30 dias, use `aitotokens_usage`. Para recargas anteriores, use `aitotokens_recharge_history`. Para conferir o estado de um pedido específico, use `aitotokens_recharge_status` com o identificador do pedido.
- Quando o usuário pedir para recarregar, consulte os pacotes e informe o valor aproximado em reais. Só chame `aitotokens_create_checkout` após o usuário confirmar qual pacote quer e que deseja gerar o link. Apresente o link para o próprio usuário abrir e pagar.
- Quando o saldo estiver baixo ou insuficiente, explique o estado indicado pela ferramenta e mostre as opções. Trate cada recarga como pendente até a confirmação do pagamento pelo sistema.
- A AitoKey é configurada localmente antes de iniciar o Codex. Se estiver ausente ou revogada, indique que o usuário deve substituir a credencial no ambiente local. Nunca peça que a chave seja colada na conversa.
- Para saber como escolher modelos, mencionar o plugin e usar os comandos, chame `aitotokens_help`.
- Para verificar atualização, chame `aitotokens_check_update`. No Windows, chame `aitotokens_open_updater` com `confirmed: true` somente se o usuário pedir expressamente para abrir o atualizador ou confirmar sua abertura. A janela confirma o download. O usuário instala o pacote verificado após encerrar o Codex.
