import { createInterface } from 'node:readline/promises';
import { createDispatcher } from './plugin/server.mjs';

const dispatch = createDispatcher();
const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

async function call(name, args = {}) {
  const { result } = await dispatch({ jsonrpc: '2.0', id: 1, method: 'tools/call', params: { name, arguments: args } });
  if (result?.isError) throw Error(result.content[0].text);
  return result;
}

async function run([command = 'saldo', amount]) {
  if (command === 'saldo') {
    const result = await call('aitotokens_status');
    console.log(result.content[0].text);
    return;
  }
  if (command === 'recarregar' && ['5', '15', '50', '100'].includes(amount)) {
    if (!process.stdin.isTTY) throw Error('Abra um terminal para confirmar a geração do link.');
    const { structuredContent: status } = await call('aitotokens_status');
    const usdCents = Number(amount) * 100;
    const plan = status.plans.find(item => item.usdCents === usdCents);
    if (!status.checkoutConfigured || !Number.isFinite(plan?.brlCents)) throw Error('O checkout está temporariamente indisponível.');
    const input = createInterface({ input: process.stdin, output: process.stdout });
    let confirmed;
    try {
      confirmed = /^s(?:im)?$/i.test((await input.question(`Gerar link de US$ ${amount} por ${brl.format(plan.brlCents / 100)}? [s/N] `)).trim());
    } finally { input.close(); }
    if (!confirmed) return;
    const result = await call('aitotokens_create_checkout', { usdCents, confirmed: true });
    console.log(result.content[0].text);
    return;
  }
  throw Error('Use node carteira.mjs saldo ou node carteira.mjs recarregar <5|15|50|100>.');
}

try { await run(process.argv.slice(2)); }
catch (error) { console.error(error.message); process.exitCode = 1; }
