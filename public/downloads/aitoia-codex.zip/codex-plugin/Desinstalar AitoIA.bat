@echo off
"%~dp0Iniciar AitoIA.exe" --uninstall
exit /b %errorlevel%
