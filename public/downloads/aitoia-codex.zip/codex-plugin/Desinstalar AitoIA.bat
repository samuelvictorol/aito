@echo off
setlocal
title Desinstalar AitoIA
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Iniciar-AitoIA.ps1" -Uninstall
set "AITO_EXIT_CODE=%errorlevel%"
pause
exit /b %AITO_EXIT_CODE%
